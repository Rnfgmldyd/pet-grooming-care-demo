/**
 * Design: Modern Clinic + Pet Care Brand
 * StatusPage v4: 보호자용 미용 진행 상황 — 완전 재설계
 * 풀스크린 상태 히어로 + 실시간 경과시간 + 강렬한 진행 시각화 + 반려견 프로필 강조
 */
import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft, RefreshCw, Phone, Clock, ArrowRight, CheckCircle2 } from "lucide-react";
import {
  STATUS_MESSAGES,
  STATUS_ORDER,
  STATUS_ICONS,
  STATUS_COLORS,
  type GroomingStatus,
} from "@/lib/store";
import { trpc } from "@/lib/trpc";
import { SHOP } from "@/lib/shop-config";

function ElapsedTime({ startedAtMs }: { startedAtMs?: number | null }) {
  const [elapsed, setElapsed] = useState("");
  useEffect(() => {
    if (!startedAtMs) return;
    const update = () => {
      const diff = Date.now() - startedAtMs;
      const m = Math.floor(diff / 60000);
      const h = Math.floor(m / 60);
      if (h > 0) setElapsed(`${h}시간 ${m % 60}분 경과`);
      else setElapsed(`${m}분 경과`);
    };
    update();
    const t = setInterval(update, 30000);
    return () => clearInterval(t);
  }, [startedAtMs]);
  if (!elapsed) return null;
  return (
    <span className="flex items-center gap-1 text-white/60 text-xs">
      <Clock size={11} />
      {elapsed}
    </span>
  );
}

export default function StatusPage() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const [countdown, setCountdown] = useState(10);
  const [justRefreshed, setJustRefreshed] = useState(false);
  const prevStatus = useRef<string>("");

  const { data: appt, isLoading, refetch } = trpc.appointments.getById.useQuery(
    { id: id || "" },
    { refetchInterval: 10000, enabled: !!id }
  );

  // 상태 변경 시 애니메이션
  useEffect(() => {
    if (appt && appt.status !== prevStatus.current) {
      if (prevStatus.current) {
        setJustRefreshed(true);
        setTimeout(() => setJustRefreshed(false), 1500);
      }
      prevStatus.current = appt.status;
    }
  }, [appt?.status]);

  const handleRefresh = () => {
    refetch();
    setCountdown(10);
  };

  useEffect(() => {
    const tick = setInterval(() => {
      setCountdown((c) => (c <= 1 ? 10 : c - 1));
    }, 1000);
    return () => clearInterval(tick);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FAFAF7] flex items-center justify-center" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>
        <div className="text-center px-6">
          <div className="w-12 h-12 border-4 border-[#1B4332]/20 border-t-[#1B4332] rounded-full animate-spin mx-auto mb-4" />
          <p className="text-[#6B7280] text-sm">정보를 불러오는 중...</p>
        </div>
      </div>
    );
  }

  if (!appt) {
    return (
      <div className="min-h-screen bg-[#FAFAF7] flex items-center justify-center" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>
        <div className="text-center px-6">
          <p className="text-5xl mb-4">🐾</p>
          <p className="text-[#1B4332] font-bold text-lg mb-2">예약 정보를 찾을 수 없습니다</p>
          <p className="text-[#6B7280] text-sm mb-6">링크가 올바른지 확인해주세요</p>
          <Button className="bg-[#1B4332] text-white rounded-xl" onClick={() => navigate("/")}>홈으로 돌아가기</Button>
        </div>
      </div>
    );
  }

  const currentIdx = STATUS_ORDER.indexOf(appt.status as GroomingStatus);
  const isComplete = appt.status === "완료";
  const isSpecial = appt.status === "특이사항있음";
  const progressPct = isComplete ? 100 : Math.round(((currentIdx + 1) / STATUS_ORDER.length) * 100);
  const color = STATUS_COLORS[appt.status as GroomingStatus] || STATUS_COLORS["접수완료"];

  // Gradient per status
  const gradients: Record<GroomingStatus, string> = {
    접수완료:     "from-[#0C4A6E] to-[#0369A1]",
    미용준비중:   "from-[#4C1D95] to-[#7C3AED]",
    목욕중:       "from-[#1E3A8A] to-[#2563EB]",
    드라이중:     "from-[#92400E] to-[#D97706]",
    커트중:       "from-[#064E3B] to-[#059669]",
    마무리중:     "from-[#831843] to-[#DB2777]",
    완료:         "from-[#1B4332] to-[#065F46]",
    특이사항있음: "from-[#7F1D1D] to-[#DC2626]",
  };
  const grad = gradients[appt.status as GroomingStatus] || gradients["접수완료"];

  return (
    <div className="min-h-screen bg-[#F4F7F4]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>

      {/* Sticky Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#E8EDE8] shadow-sm">
        <div className="max-w-lg mx-auto px-4 flex items-center h-14">
          <button onClick={() => navigate("/")} className="flex items-center gap-1 text-[#1B4332] text-sm font-medium">
            <ChevronLeft size={18} />홈
          </button>
          <div className="mx-auto text-center">
            <span className="font-bold text-[#1B4332] text-sm block leading-tight">{SHOP.logoEmoji} {SHOP.name}</span>
            <span className="text-[10px] text-[#9CA3AF]">실시간 미용 현황</span>
          </div>
          <button
            onClick={handleRefresh}
            className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[#F0FDF4] text-[#1B4332] transition-all"
          >
            <RefreshCw size={15} />
          </button>
        </div>
      </header>

      {/* ── HERO STATUS ── */}
      <div className={`relative overflow-hidden bg-gradient-to-br ${grad} px-5 pt-8 pb-24`}>
        {/* Animated background circles */}
        <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-white/5 -translate-y-1/3 translate-x-1/3" />
        <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full bg-white/5 translate-y-1/2 -translate-x-1/4" />

        {/* Pulse ring for active status */}
        {!isComplete && (
          <div className="absolute top-10 right-10 w-16 h-16 rounded-full border-2 border-white/20 animate-ping opacity-30" />
        )}

        <div className="relative max-w-lg mx-auto">
          {/* Live / Complete badge */}
          <div className="flex items-center justify-between mb-6">
            <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm border border-white/20 rounded-full px-3 py-1.5">
              {isComplete ? (
                <CheckCircle2 size={12} className="text-[#6EE7B7]" />
              ) : (
                <span className="w-2 h-2 rounded-full bg-white/80 animate-pulse" />
              )}
              <span className="text-xs font-semibold text-white">
                {isComplete ? "미용 완료" : isSpecial ? "특이사항 발생" : "미용 진행 중"}
              </span>
            </div>
            <ElapsedTime startedAtMs={appt.startedAt} />
          </div>

          {/* Dog profile */}
          <div className="flex items-center gap-5 mb-8">
            <div className="relative flex-shrink-0">
              <div className="w-24 h-24 rounded-3xl bg-white/20 flex items-center justify-center text-6xl border-2 border-white/30 shadow-2xl">
                🐶
              </div>
              {/* Status dot */}
              <div
                className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full border-2 border-white flex items-center justify-center text-sm shadow-lg"
                style={{ background: color.bg }}
              >
                {STATUS_ICONS[appt.status as GroomingStatus]}
              </div>
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white leading-none mb-2" style={{ fontFamily: "'Noto Serif KR', serif" }}>
                {appt.dogName}
              </h1>
              <p className="text-white/70 text-sm mb-1">{appt.breed} · {appt.age} · {(appt as any).weight || ""}</p>
              <p className="text-white/50 text-xs">{appt.ownerName} 보호자님</p>
            </div>
          </div>

          {/* Current status big card */}
          <div className={`bg-white/15 backdrop-blur-sm rounded-3xl p-5 border border-white/20 shadow-xl transition-all duration-500 ${justRefreshed ? "scale-[1.02]" : ""}`}>
            <p className="text-white/50 text-[10px] font-bold uppercase tracking-widest mb-2">현재 단계</p>
            <div className="flex items-center gap-4 mb-3">
              <span className="text-5xl leading-none">{STATUS_ICONS[appt.status as GroomingStatus]}</span>
              <div>
                <p className="text-white font-bold text-2xl leading-tight">{appt.status}</p>
                <p className="text-white/60 text-xs mt-0.5">
                  {appt.updatedAt ? `${new Date(appt.updatedAt).toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" })} 업데이트` : ""}
                </p>
              </div>
            </div>
            <p className="text-white/80 text-sm leading-relaxed">
              {STATUS_MESSAGES[appt.status as GroomingStatus]}
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 -mt-12 pb-10 space-y-4">

        {/* Progress Card */}
        <div className="bg-white rounded-3xl border border-[#E8EDE8] shadow-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-[#1B4332]">미용 진행률</h3>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold text-[#1B4332]">{progressPct}%</span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="w-full h-3 bg-[#F3F4F6] rounded-full overflow-hidden mb-5">
            <div
              className="h-full rounded-full transition-all duration-1000 ease-out relative overflow-hidden"
              style={{
                width: `${progressPct}%`,
                background: `linear-gradient(90deg, ${color.bg}, ${color.bg}cc)`,
              }}
            >
              {/* Shimmer */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-[shimmer_2s_infinite]" />
            </div>
          </div>

          {/* Step indicators */}
          <div className="flex items-start justify-between gap-1">
            {STATUS_ORDER.map((status, idx) => {
              const isDone = idx <= currentIdx;
              const isCurrent = idx === currentIdx;
              const sc = STATUS_COLORS[status];
              return (
                <div key={status} className="flex flex-col items-center gap-1.5 flex-1 min-w-0">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm transition-all duration-300 ${
                      isCurrent
                        ? "shadow-lg scale-125 ring-4 ring-offset-1 ring-white"
                        : isDone
                        ? "opacity-90"
                        : "bg-[#F3F4F6] text-[#D1D5DB]"
                    }`}
                    style={
                      isCurrent
                        ? { background: sc.bg, color: "white" }
                        : isDone
                        ? { background: sc.bg, color: "white" }
                        : {}
                    }
                  >
                    {isDone && !isCurrent ? "✓" : STATUS_ICONS[status]}
                  </div>
                  <span className={`text-[9px] text-center leading-tight break-keep ${isCurrent ? "font-bold text-[#1B4332]" : isDone ? "text-[#6B7280]" : "text-[#D1D5DB]"}`}>
                    {status}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Request Summary */}
        <div className="bg-white rounded-3xl border border-[#E8EDE8] shadow-sm overflow-hidden">
          <div className="px-5 py-3.5 border-b border-[#F3F4F6] bg-[#FAFAFA] flex items-center gap-2">
            <span className="text-sm">✂️</span>
            <h3 className="text-xs font-bold text-[#6B7280] uppercase tracking-wider">미용 요청사항</h3>
          </div>
          <div className="px-5 py-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#9CA3AF]">미용 스타일</span>
              <span className="text-xs font-bold text-[#1B4332] bg-[#F0FDF4] px-3 py-1 rounded-full border border-[#D1FAE5]">
                {appt.groomingRequest}
              </span>
            </div>
            {appt.sensitiveParts.length > 0 && (
              <div className="flex items-start justify-between gap-3">
                <span className="text-xs text-[#9CA3AF] flex-shrink-0">예민한 부위</span>
                <div className="flex gap-1 flex-wrap justify-end">
                  {appt.sensitiveParts.map((p: string) => (
                    <span key={p} className="text-xs font-bold text-[#991B1B] bg-[#FEE2E2] px-2 py-0.5 rounded-full">
                      ⚠️ {p}
                    </span>
                  ))}
                </div>
              </div>
            )}
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#9CA3AF]">예상 소요시간</span>
              <span className="text-xs font-bold text-[#1B4332] flex items-center gap-1">
                <Clock size={11} className="text-[#6B7280]" />{appt.estimatedTime}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#9CA3AF]">피부 상태</span>
              <span className="text-xs font-bold text-[#065F46] bg-[#D1FAE5] px-2.5 py-0.5 rounded-full">
                {appt.skinCondition}
              </span>
            </div>
            {appt.biteRisk && (
              <div className="bg-[#FEF3C7] rounded-2xl px-4 py-3 flex items-center gap-2.5 border border-[#FDE68A]">
                <span className="text-lg">⚠️</span>
                <p className="text-xs text-[#92400E] font-semibold leading-relaxed">
                  입질 주의 — 담당자가 안전하게 진행 중입니다
                </p>
              </div>
            )}
            {appt.notes && (
              <div className="bg-[#F0FDF4] rounded-2xl px-4 py-3 border border-[#D1FAE5]">
                <p className="text-[10px] text-[#6B7280] mb-1 font-bold uppercase tracking-wider">추가 요청사항</p>
                <p className="text-xs text-[#1B4332] leading-relaxed">{appt.notes}</p>
              </div>
            )}
          </div>
        </div>

        {/* Staff note */}
        {appt.staffNote && (
          <div className="bg-[#FEF9C3] rounded-3xl border border-[#FDE68A] p-4 shadow-sm">
            <p className="text-xs font-bold text-[#92400E] mb-1.5 flex items-center gap-1.5">
              💬 담당자 메모
            </p>
            <p className="text-xs text-[#78350F] leading-relaxed">{appt.staffNote}</p>
          </div>
        )}

        {/* Auto-refresh + Contact row */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-2xl border border-[#E8EDE8] p-4 flex items-center gap-3 shadow-sm">
            <div className="w-9 h-9 rounded-xl bg-[#F0FDF4] flex items-center justify-center flex-shrink-0">
              <div className="w-2.5 h-2.5 rounded-full bg-[#34D399] animate-pulse" />
            </div>
            <div>
              <p className="text-[10px] text-[#9CA3AF] leading-none mb-0.5">자동 새로고침</p>
              <p className="text-sm font-bold text-[#1B4332]">{countdown}초 후</p>
            </div>
          </div>
          <a
            href={`tel:${SHOP.phone}`}
            className="bg-white rounded-2xl border border-[#E8EDE8] p-4 flex items-center gap-3 hover:border-[#1B4332]/30 hover:bg-[#F0FDF4] transition-all shadow-sm"
          >
            <div className="w-9 h-9 rounded-xl bg-[#F0FDF4] flex items-center justify-center flex-shrink-0">
              <Phone size={15} className="text-[#1B4332]" />
            </div>
            <div>
              <p className="text-[10px] text-[#9CA3AF] leading-none mb-0.5">긴급 문의</p>
              <p className="text-sm font-bold text-[#1B4332]">전화하기</p>
            </div>
          </a>
        </div>

        {/* Last updated */}
        <p className="text-center text-[10px] text-[#C4C9C4]">
          마지막 확인: {new Date().toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
        </p>

        {/* Complete CTA */}
        {isComplete && (
          <Button
            className="w-full h-14 text-sm font-bold rounded-2xl shadow-xl animate-bounce"
            style={{ background: "linear-gradient(135deg, #1B4332, #065F46)", color: "white" }}
            onClick={() => navigate(`/complete/${appt.id}`)}
          >
            🎉 미용 완료 안내 확인하기 <ArrowRight size={16} className="ml-1.5" />
          </Button>
        )}

        <div className="h-4" />
      </div>
    </div>
  );
}
