/**
 * 직원 로그인 페이지 - 4자리 PIN 입력
 * Design: Modern Clinic + Pet Care Brand
 */
import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { Scissors, Lock, Eye, EyeOff, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useShop } from "@/contexts/ShopContext";

export default function StaffLoginPage() {
  const [, navigate] = useLocation();
  const { shop } = useShop();
  const shopName = shop?.name ?? "그루밍노트";
  const [pin, setPin] = useState(["", "", "", ""]);
  const [showPin, setShowPin] = useState(false);
  const [isSetupMode, setIsSetupMode] = useState(false);
  const [setupStep, setSetupStep] = useState<"new" | "confirm">("new");
  const [firstPin, setFirstPin] = useState<string>("");
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const { data: pinStatus, isLoading: checkingPin } = trpc.staff.hasPinSetup.useQuery();
  const utils = trpc.useUtils();
  const verifyPin = trpc.staff.verifyPin.useMutation();
  const setNewPin = trpc.staff.setPin.useMutation();

  useEffect(() => {
    if (!checkingPin && pinStatus) {
      setIsSetupMode(!pinStatus.hasPin);
    }
  }, [pinStatus, checkingPin]);

  // 첫 번째 입력칸에 포커스
  useEffect(() => {
    setTimeout(() => inputRefs.current[0]?.focus(), 100);
  }, [isSetupMode, setupStep]);

  const currentPin = pin.join("");

  const handleDigitInput = (index: number, value: string) => {
    if (!/^\d?$/.test(value)) return;
    const newPin = [...pin];
    newPin[index] = value;
    setPin(newPin);
    if (value && index < 3) {
      inputRefs.current[index + 1]?.focus();
    }
    // 4자리 모두 입력되면 자동 제출
    if (value && index === 3) {
      const fullPin = [...newPin].join("");
      if (fullPin.length === 4) {
        setTimeout(() => handleSubmit(fullPin), 100);
      }
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !pin[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const resetPin = () => {
    setPin(["", "", "", ""]);
    setTimeout(() => inputRefs.current[0]?.focus(), 50);
  };

  const handleSubmit = async (submittedPin?: string) => {
    const finalPin = submittedPin ?? currentPin;
    if (finalPin.length !== 4) return;

    if (isSetupMode) {
      if (setupStep === "new") {
        setFirstPin(finalPin);
        setSetupStep("confirm");
        resetPin();
        return;
      } else {
        // 확인 단계
        if (finalPin !== firstPin) {
          toast.error("비밀번호가 일치하지 않습니다. 다시 입력해주세요.");
          setSetupStep("new");
          setFirstPin("");
          resetPin();
          return;
        }
      try {
        await setNewPin.mutateAsync({ pin: finalPin });
        toast.success("비밀번호가 설정되었습니다!");
        // 인증 캐시 무효화 후 이동
        await utils.staff.isAuthenticated.invalidate();
        navigate("/staff");
      } catch (err: any) {
        toast.error(err.message || "설정 실패");
        resetPin();
      }
      }
    } else {
      try {
        await verifyPin.mutateAsync({ pin: finalPin });
        toast.success("로그인 성공!");
        // 인증 캐시 무효화 후 이동 (캐시된 미인증 상태로 인한 리다이렉트 방지)
        await utils.staff.isAuthenticated.invalidate();
        navigate("/staff");
      } catch (err: any) {
        toast.error(err.message || "비밀번호가 올바르지 않습니다");
        resetPin();
      }
    }
  };

  const isPending = verifyPin.isPending || setNewPin.isPending;

  const getTitle = () => {
    if (isSetupMode) {
      return setupStep === "new" ? "비밀번호 설정" : "비밀번호 확인";
    }
    return "직원 로그인";
  };

  const getSubtitle = () => {
    if (isSetupMode) {
      return setupStep === "new"
        ? "4자리 숫자 비밀번호를 설정해주세요"
        : "비밀번호를 한 번 더 입력해주세요";
    }
    return "4자리 비밀번호를 입력해주세요";
  };

  if (checkingPin) {
    return (
      <div className="min-h-screen bg-[#F4F7F4] flex items-center justify-center">
        <div className="text-[#1B4332] text-sm">확인 중...</div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-[#F4F7F4] flex flex-col items-center justify-center px-4"
      style={{ fontFamily: "'Noto Sans KR', sans-serif" }}
    >
      {/* 뒤로가기 */}
      <button
        onClick={() => navigate("/")}
        className="absolute top-5 left-5 flex items-center gap-1.5 text-[#6B7280] text-sm hover:text-[#1B4332] transition-colors"
      >
        <ArrowLeft size={16} />
        홈으로
      </button>

      <div className="w-full max-w-sm">
        {/* 로고 */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-[#1B4332] flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Scissors size={28} className="text-white" />
          </div>
          <p className="text-xs text-[#9CA3AF] font-medium">{shopName}</p>
        </div>

        {/* 카드 */}
        <div className="bg-white rounded-3xl shadow-xl border border-[#E8EDE8] p-8">
          {/* 제목 */}
          <div className="text-center mb-7">
            <div className="w-10 h-10 rounded-xl bg-[#F0FDF4] flex items-center justify-center mx-auto mb-3">
              <Lock size={18} className="text-[#1B4332]" />
            </div>
            <h1 className="text-lg font-bold text-[#1B4332] mb-1">{getTitle()}</h1>
            <p className="text-xs text-[#9CA3AF]">{getSubtitle()}</p>
          </div>

          {/* PIN 입력 */}
          <div className="flex justify-center gap-3 mb-6">
            {pin.map((digit, i) => (
              <input
                key={i}
                ref={el => { inputRefs.current[i] = el; }}
                type={showPin ? "text" : "password"}
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={e => handleDigitInput(i, e.target.value)}
                onKeyDown={e => handleKeyDown(i, e)}
                disabled={isPending}
                className={`w-14 h-14 text-center text-xl font-bold rounded-2xl border-2 outline-none transition-all duration-150
                  ${digit
                    ? "border-[#1B4332] bg-[#F0FDF4] text-[#1B4332]"
                    : "border-[#E8EDE8] bg-[#FAFAFA] text-[#1B4332]"
                  }
                  focus:border-[#1B4332] focus:bg-[#F0FDF4]
                  disabled:opacity-50`}
              />
            ))}
          </div>

          {/* 비밀번호 표시 토글 */}
          <div className="flex justify-center mb-6">
            <button
              type="button"
              onClick={() => setShowPin(!showPin)}
              className="flex items-center gap-1.5 text-xs text-[#9CA3AF] hover:text-[#1B4332] transition-colors"
            >
              {showPin ? <EyeOff size={13} /> : <Eye size={13} />}
              {showPin ? "숨기기" : "표시하기"}
            </button>
          </div>

          {/* 숫자 키패드 */}
          <div className="grid grid-cols-3 gap-2 mb-5">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => (
              <button
                key={n}
                type="button"
                disabled={isPending}
                onClick={() => {
                  const emptyIdx = pin.findIndex(d => d === "");
                  if (emptyIdx !== -1) {
                    handleDigitInput(emptyIdx, String(n));
                  }
                }}
                className="h-12 rounded-xl bg-[#F4F7F4] text-[#1B4332] font-bold text-lg hover:bg-[#E8EDE8] active:scale-95 transition-all duration-100 disabled:opacity-50"
              >
                {n}
              </button>
            ))}
            <button
              type="button"
              disabled={isPending}
              onClick={resetPin}
              className="h-12 rounded-xl bg-[#FEE2E2] text-[#DC2626] font-bold text-sm hover:bg-[#FECACA] active:scale-95 transition-all duration-100 disabled:opacity-50"
            >
              지우기
            </button>
            <button
              type="button"
              disabled={isPending}
              onClick={() => {
                const emptyIdx = pin.findIndex(d => d === "");
                if (emptyIdx !== -1) {
                  handleDigitInput(emptyIdx, "0");
                }
              }}
              className="h-12 rounded-xl bg-[#F4F7F4] text-[#1B4332] font-bold text-lg hover:bg-[#E8EDE8] active:scale-95 transition-all duration-100 disabled:opacity-50"
            >
              0
            </button>
            <button
              type="button"
              disabled={isPending || currentPin.length !== 4}
              onClick={() => handleSubmit()}
              className="h-12 rounded-xl bg-[#1B4332] text-white font-bold text-sm hover:bg-[#145229] active:scale-95 transition-all duration-100 disabled:opacity-40"
            >
              확인
            </button>
          </div>

          {/* 설정 모드 안내 */}
          {isSetupMode && setupStep === "confirm" && (
            <button
              onClick={() => { setSetupStep("new"); setFirstPin(""); resetPin(); }}
              className="w-full text-xs text-[#9CA3AF] hover:text-[#1B4332] transition-colors text-center"
            >
              ← 처음부터 다시 설정
            </button>
          )}
        </div>

        {/* 하단 안내 */}
        {!isSetupMode && (
          <p className="text-center text-xs text-[#9CA3AF] mt-5">
            비밀번호를 잊으셨나요?{" "}
            <button
              onClick={() => toast.info("관리자에게 문의해주세요")}
              className="text-[#1B4332] font-medium hover:underline"
            >
              관리자 문의
            </button>
          </p>
        )}
      </div>
    </div>
  );
}
