/**
 * 전체 접수 이력 페이지 - 직원 전용
 * Design: Modern Clinic + Pet Care Brand
 */
import { useState, useMemo, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import {
  ChevronLeft, Search, Filter, Calendar, Clock,
  AlertTriangle, CheckCircle2, RefreshCw, User, Scissors
} from "lucide-react";
import { SHOP } from "@/lib/shop-config";
import { STATUS_COLORS, STATUS_ICONS, type GroomingStatus } from "@/lib/store";

function formatDate(ms: number): string {
  return new Date(ms).toLocaleDateString("ko-KR", {
    month: "2-digit", day: "2-digit",
  });
}

function formatTime(ms: number): string {
  return new Date(ms).toLocaleTimeString("ko-KR", {
    hour: "2-digit", minute: "2-digit",
  });
}

function formatDateTime(ms: number): string {
  return new Date(ms).toLocaleString("ko-KR", {
    month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit",
  });
}

function getDurationText(createdAt: number, completedAt: number | null | undefined): string {
  if (!completedAt) return "-";
  const diff = completedAt - createdAt;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 60) return `${minutes}분`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m > 0 ? `${h}시간 ${m}분` : `${h}시간`;
}

type FilterStatus = "전체" | GroomingStatus;
type FilterSource = "전체" | "staff" | "owner";

export default function HistoryPage() {
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<FilterStatus>("전체");
  const [filterSource, setFilterSource] = useState<FilterSource>("전체");
  const [filterDate, setFilterDate] = useState("");

  // PIN 인증 체크
  const { data: authData, isLoading: authLoading } = trpc.staff.isAuthenticated.useQuery();
  useEffect(() => {
    if (!authLoading && authData && !authData.authenticated) {
      navigate("/staff-login");
    }
  }, [authData, authLoading]);

  const { data: appointments = [], isLoading, refetch, isRefetching } = trpc.appointments.listAll.useQuery(
    { limit: 300 },
    { refetchInterval: 30000 }
  );

  const filtered = useMemo(() => {
    return appointments.filter(appt => {
      // 검색어 필터
      if (search) {
        const q = search.toLowerCase();
        const match =
          appt.dogName.toLowerCase().includes(q) ||
          appt.ownerName.toLowerCase().includes(q) ||
          appt.phone.includes(q) ||
          appt.breed.toLowerCase().includes(q);
        if (!match) return false;
      }
      // 상태 필터
      if (filterStatus !== "전체" && appt.status !== filterStatus) return false;
      // 접수 출처 필터
      if (filterSource !== "전체" && appt.source !== filterSource) return false;
      // 날짜 필터
      if (filterDate) {
        const apptDate = new Date(appt.createdAt).toLocaleDateString("ko-KR", {
          year: "numeric", month: "2-digit", day: "2-digit"
        }).replace(/\. /g, "-").replace(".", "");
        const filterDateFormatted = new Date(filterDate).toLocaleDateString("ko-KR", {
          year: "numeric", month: "2-digit", day: "2-digit"
        }).replace(/\. /g, "-").replace(".", "");
        if (apptDate !== filterDateFormatted) return false;
      }
      return true;
    });
  }, [appointments, search, filterStatus, filterSource, filterDate]);

  // 통계
  const stats = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayMs = today.getTime();
    const todayCount = appointments.filter(a => a.createdAt >= todayMs).length;
    const completedCount = appointments.filter(a => a.status === "완료").length;
    const ownerCount = appointments.filter(a => a.source === "owner").length;
    return { total: appointments.length, todayCount, completedCount, ownerCount };
  }, [appointments]);

  const statusOptions: FilterStatus[] = [
    "전체", "접수완료", "미용준비중", "목욕중", "드라이중", "커트중", "마무리중", "완료", "특이사항있음"
  ];

  return (
    <div
      className="min-h-screen bg-[#F4F7F4]"
      style={{ fontFamily: "'Noto Sans KR', sans-serif" }}
    >
      {/* 헤더 */}
      <header className="sticky top-0 z-50 bg-white border-b border-[#E8EDE8] shadow-sm">
        <div className="max-w-3xl mx-auto px-4 flex items-center justify-between h-14">
          <button
            onClick={() => navigate("/staff")}
            className="flex items-center gap-1 text-[#1B4332] text-sm font-medium"
          >
            <ChevronLeft size={18} />직원 화면
          </button>
          <div className="text-center">
            <p className="font-bold text-[#1B4332] text-sm leading-tight">📋 전체 접수 이력</p>
            <p className="text-[10px] text-[#9CA3AF]">{SHOP.name}</p>
          </div>
          <button
            onClick={() => refetch()}
            disabled={isRefetching}
            className={`w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[#F0FDF4] text-[#1B4332] transition-all ${isRefetching ? "animate-spin" : ""}`}
          >
            <RefreshCw size={15} />
          </button>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-4 py-5 space-y-4">

        {/* 통계 카드 */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { label: "전체", value: stats.total, icon: "📊", color: "#E0F2FE" },
            { label: "오늘", value: stats.todayCount, icon: "📅", color: "#D1FAE5" },
            { label: "완료", value: stats.completedCount, icon: "✅", color: "#F0FDF4" },
            { label: "보호자접수", value: stats.ownerCount, icon: "📱", color: "#FEF9C3" },
          ].map((s, i) => (
            <div key={i} className="bg-white rounded-2xl border border-[#E8EDE8] p-3 shadow-sm text-center">
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center mx-auto mb-1.5 text-sm"
                style={{ background: s.color }}
              >
                {s.icon}
              </div>
              <p className="text-lg font-bold text-[#1B4332]">{s.value}</p>
              <p className="text-[9px] text-[#9CA3AF]">{s.label}</p>
            </div>
          ))}
        </div>

        {/* 검색 및 필터 */}
        <div className="bg-white rounded-2xl border border-[#E8EDE8] p-4 shadow-sm space-y-3">
          {/* 검색 */}
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            <input
              type="text"
              placeholder="반려견 이름, 보호자, 전화번호 검색..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 text-sm bg-[#F4F7F4] border border-[#E8EDE8] rounded-xl outline-none focus:border-[#1B4332]/40 text-[#1B4332] placeholder-[#9CA3AF]"
            />
          </div>

          {/* 날짜 필터 */}
          <div className="flex items-center gap-2">
            <Calendar size={13} className="text-[#9CA3AF] flex-shrink-0" />
            <input
              type="date"
              value={filterDate}
              onChange={e => setFilterDate(e.target.value)}
              className="flex-1 text-xs bg-[#F4F7F4] border border-[#E8EDE8] rounded-xl px-3 py-2 outline-none focus:border-[#1B4332]/40 text-[#1B4332]"
            />
            {filterDate && (
              <button
                onClick={() => setFilterDate("")}
                className="text-xs text-[#9CA3AF] hover:text-[#DC2626] transition-colors"
              >
                초기화
              </button>
            )}
          </div>

          {/* 접수 출처 필터 */}
          <div className="flex items-center gap-2">
            <Filter size={13} className="text-[#9CA3AF] flex-shrink-0" />
            <div className="flex gap-1.5 flex-wrap">
              {(["전체", "staff", "owner"] as FilterSource[]).map(src => (
                <button
                  key={src}
                  onClick={() => setFilterSource(src)}
                  className={`text-[10px] font-bold px-2.5 py-1 rounded-full transition-all ${
                    filterSource === src
                      ? "bg-[#1B4332] text-white"
                      : "bg-[#F4F7F4] text-[#6B7280] hover:bg-[#E8EDE8]"
                  }`}
                >
                  {src === "전체" ? "전체" : src === "staff" ? "직원접수" : "보호자접수"}
                </button>
              ))}
            </div>
          </div>

          {/* 상태 필터 */}
          <div className="flex gap-1.5 flex-wrap">
            {statusOptions.map(s => {
              const color = s !== "전체" ? STATUS_COLORS[s as GroomingStatus] : null;
              const isActive = filterStatus === s;
              return (
                <button
                  key={s}
                  onClick={() => setFilterStatus(s)}
                  className={`text-[10px] font-bold px-2.5 py-1 rounded-full transition-all ${
                    isActive
                      ? "text-white"
                      : "bg-[#F4F7F4] text-[#6B7280] hover:bg-[#E8EDE8]"
                  }`}
                  style={isActive && color ? { background: color.bg } : {}}
                >
                  {s !== "전체" && STATUS_ICONS[s as GroomingStatus]} {s}
                </button>
              );
            })}
          </div>
        </div>

        {/* 결과 수 */}
        <div className="flex items-center justify-between px-1">
          <p className="text-xs text-[#9CA3AF]">
            총 <span className="font-bold text-[#1B4332]">{filtered.length}</span>건
          </p>
          {(search || filterStatus !== "전체" || filterSource !== "전체" || filterDate) && (
            <button
              onClick={() => { setSearch(""); setFilterStatus("전체"); setFilterSource("전체"); setFilterDate(""); }}
              className="text-xs text-[#DC2626] hover:underline"
            >
              필터 초기화
            </button>
          )}
        </div>

        {/* 이력 목록 */}
        {isLoading ? (
          <div className="text-center py-12 text-[#9CA3AF] text-sm">불러오는 중...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-4xl mb-3">🔍</div>
            <p className="text-[#9CA3AF] text-sm">검색 결과가 없습니다</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map(appt => {
              const color = STATUS_COLORS[appt.status as GroomingStatus] || STATUS_COLORS["접수완료"];
              const isComplete = appt.status === "완료";
              return (
                <button
                  key={appt.id}
                  onClick={() => navigate(`/status/${appt.id}`)}
                  className="w-full bg-white rounded-2xl border border-[#E8EDE8] shadow-sm hover:shadow-md hover:border-[#1B4332]/20 transition-all duration-200 overflow-hidden text-left"
                >
                  {/* 상태 색상 바 */}
                  <div className="h-1" style={{ background: color.bg }} />
                  <div className="px-4 py-3 flex items-center gap-3">
                    {/* 상태 아이콘 */}
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
                      style={{ background: color.light }}
                    >
                      {STATUS_ICONS[appt.status as GroomingStatus]}
                    </div>

                    {/* 메인 정보 */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                        <span className="font-bold text-[#1B4332] text-sm">{appt.dogName}</span>
                        <span className="text-[10px] text-[#9CA3AF]">{appt.breed}</span>
                        {appt.biteRisk && (
                          <span className="text-[9px] bg-[#FEE2E2] text-[#DC2626] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                            <AlertTriangle size={8} />입질
                          </span>
                        )}
                        <span
                          className="text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                          style={{ background: color.light, color: color.bg }}
                        >
                          {appt.status}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-[10px] text-[#9CA3AF]">
                        <span className="flex items-center gap-0.5">
                          <User size={9} />{appt.ownerName}
                        </span>
                        <span className="flex items-center gap-0.5">
                          <Clock size={9} />{formatDateTime(appt.createdAt)}
                        </span>
                        {isComplete && appt.completedAt && (
                          <span className="flex items-center gap-0.5 text-[#059669]">
                            <CheckCircle2 size={9} />{getDurationText(appt.createdAt, appt.completedAt)}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* 접수 출처 */}
                    <div className="flex-shrink-0 text-right">
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                        appt.source === "owner"
                          ? "bg-[#FEF9C3] text-[#92400E]"
                          : "bg-[#EDE9FE] text-[#7C3AED]"
                      }`}>
                        {appt.source === "owner" ? "📱 보호자" : "👩‍💼 직원"}
                      </span>
                      <p className="text-[9px] text-[#9CA3AF] mt-1">{appt.phone}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
