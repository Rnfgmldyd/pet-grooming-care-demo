/**
 * Design: Modern Clinic + Pet Care Brand
 * StaffPage v5: 직원용 관리 화면 — DB 연동 + PIN 인증 체크
 */
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  ChevronLeft, Copy, ArrowRight, Plus, Clock,
  CheckCircle2, AlertTriangle, Scissors, RefreshCw, Check,
  History, LogOut
} from "lucide-react";
import {
  STATUS_ORDER,
  STATUS_ICONS,
  STATUS_COLORS,
  type GroomingStatus,
} from "@/lib/store";
import { trpc } from "@/lib/trpc";
import { useShop } from "@/contexts/ShopContext";

const NEXT_STATUS: Partial<Record<GroomingStatus, GroomingStatus>> = {
  접수완료: "미용준비중",
  미용준비중: "목욕중",
  목욕중: "드라이중",
  드라이중: "커트중",
  커트중: "마무리중",
  마무리중: "완료",
};

const STATUS_LABELS: Record<GroomingStatus, string> = {
  접수완료: "접수",
  미용준비중: "준비중",
  목욕중: "목욕",
  드라이중: "드라이",
  커트중: "커트",
  마무리중: "마무리",
  완료: "완료",
  특이사항있음: "특이사항",
};

function ElapsedBadge({ startedAtMs }: { startedAtMs?: number | null }) {
  const [elapsed, setElapsed] = useState("");
  useEffect(() => {
    if (!startedAtMs) return;
    const update = () => {
      const diff = Date.now() - startedAtMs;
      const m = Math.floor(diff / 60000);
      const h = Math.floor(m / 60);
      setElapsed(h > 0 ? `${h}h ${m % 60}m` : `${m}m`);
    };
    update();
    const t = setInterval(update, 30000);
    return () => clearInterval(t);
  }, [startedAtMs]);
  if (!elapsed) return null;
  return (
    <span className="flex items-center gap-1 text-[10px] text-[#9CA3AF]">
      <Clock size={9} />{elapsed}
    </span>
  );
}

function AppointmentCard({ appt, onUpdate }: { appt: any; onUpdate: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const [note, setNote] = useState(appt.staffNote || "");

  const currentIdx = STATUS_ORDER.indexOf(appt.status as GroomingStatus);
  const nextStatus = NEXT_STATUS[appt.status as GroomingStatus];
  const isComplete = appt.status === "완료";
  const color = STATUS_COLORS[appt.status as GroomingStatus] || STATUS_COLORS["접수완료"];
  const progressPct = isComplete ? 100 : Math.round(((currentIdx + 1) / STATUS_ORDER.length) * 100);

  const updateStatus = trpc.appointments.updateStatus.useMutation({
    onSuccess: () => onUpdate(),
    onError: () => toast.error("상태 변경 실패"),
  });

  const handleStatusChange = (status: GroomingStatus) => {
    updateStatus.mutate({ id: appt.id, status, staffNote: note });
    toast.success(`${appt.dogName} → "${status}"`, {
      description: "보호자 화면에 즉시 반영됩니다",
      duration: 2000,
    });
  };

  const handleNoteBlur = () => {
    if (note !== appt.staffNote) {
      updateStatus.mutate({ id: appt.id, status: appt.status as GroomingStatus, staffNote: note });
    }
  };

  const handleCopyLink = () => {
    const url = `${window.location.origin}/status/${appt.id}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      toast.success(`${appt.dogName} 보호자 링크 복사됨`);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div
      className={`bg-white rounded-3xl border-2 shadow-sm overflow-hidden transition-all duration-300 ${
        expanded ? "border-[#1B4332]/30 shadow-lg" : "border-[#E8EDE8] hover:border-[#1B4332]/20"
      }`}
    >
      {/* Color stripe */}
      <div className="h-1.5 w-full" style={{ background: color.bg }} />

      {/* Card header */}
      <button
        className="w-full px-5 py-4 flex items-center gap-4 text-left"
        onClick={() => setExpanded(!expanded)}
      >
        <div
          className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 shadow-sm"
          style={{ background: color.light }}
        >
          {STATUS_ICONS[appt.status as GroomingStatus]}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5 flex-wrap">
            <span className="font-bold text-[#1B4332] text-base">{appt.dogName}</span>
            <span className="text-[10px] text-[#9CA3AF]">{appt.breed}</span>
            {appt.biteRisk && (
              <span className="text-[10px] bg-[#FEE2E2] text-[#DC2626] font-bold px-2 py-0.5 rounded-full flex items-center gap-0.5">
                <AlertTriangle size={9} />입질주의
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 mb-2">
            <span
              className="text-[10px] font-bold px-2 py-0.5 rounded-full"
              style={{ background: color.light, color: color.bg }}
            >
              {appt.status}
            </span>
            <ElapsedBadge startedAtMs={appt.startedAt} />
          </div>
          <div className="w-full h-1.5 bg-[#F3F4F6] rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{ width: `${progressPct}%`, background: color.bg }}
            />
          </div>
        </div>

        <div className="text-right flex-shrink-0">
          <p className="text-xs font-bold text-[#1B4332]">{appt.ownerName}</p>
          <p className="text-[10px] text-[#9CA3AF]">
            {new Date(appt.createdAt).toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" })}
          </p>
          <p className="text-[10px] text-[#C4C9C4] mt-0.5">{expanded ? "▲ 닫기" : "▼ 열기"}</p>
        </div>
      </button>

      {/* Expanded content */}
      {expanded && (
        <div className="border-t border-[#F3F4F6] px-5 py-4 space-y-4">

          {/* NEXT STEP */}
          {nextStatus && (
            <button
              onClick={() => handleStatusChange(nextStatus)}
              className="w-full flex items-center justify-between rounded-2xl px-5 py-4 transition-all duration-150 active:scale-[0.98] shadow-md hover:shadow-lg"
              style={{ background: `linear-gradient(135deg, ${STATUS_COLORS[nextStatus].bg}, ${STATUS_COLORS[nextStatus].bg}cc)` }}
            >
              <div className="flex items-center gap-3">
                <span className="text-3xl">{STATUS_ICONS[nextStatus]}</span>
                <div className="text-left">
                  <p className="text-[10px] text-white/60 leading-none mb-1 uppercase tracking-wider">다음 단계로 이동</p>
                  <p className="text-base font-bold text-white leading-none">{nextStatus}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-white/70">탭하여 변경</span>
                <ArrowRight size={18} className="text-white" />
              </div>
            </button>
          )}

          {/* Request details */}
          <div className="bg-[#FAFAFA] rounded-2xl p-4 space-y-2.5">
            <div className="flex justify-between items-start">
              <span className="text-xs text-[#9CA3AF]">미용 요청</span>
              <span className="text-xs font-bold text-[#1B4332] text-right max-w-[60%]">{appt.groomingRequest}</span>
            </div>
            {appt.sensitiveParts && appt.sensitiveParts.length > 0 && (
              <div className="flex justify-between items-start">
                <span className="text-xs text-[#9CA3AF] flex-shrink-0">예민 부위</span>
                <div className="flex gap-1 flex-wrap justify-end">
                  {appt.sensitiveParts.map((p: string) => (
                    <span key={p} className="text-[10px] font-bold text-[#991B1B] bg-[#FEE2E2] px-2 py-0.5 rounded-full">
                      ⚠️ {p}
                    </span>
                  ))}
                </div>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-xs text-[#9CA3AF]">피부 상태</span>
              <span className="text-xs font-bold text-[#065F46]">{appt.skinCondition}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-[#9CA3AF]">예상 소요</span>
              <span className="text-xs font-bold text-[#1B4332]">{appt.estimatedTime}</span>
            </div>
            {appt.notes && (
              <div className="pt-2 border-t border-[#EBEBEB]">
                <p className="text-[10px] text-[#9CA3AF] mb-1">보호자 메모</p>
                <p className="text-xs text-[#374151] leading-relaxed">{appt.notes}</p>
              </div>
            )}
          </div>

          {/* Staff note */}
          <div>
            <label className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider block mb-1.5">
              💬 담당자 메모 (보호자에게 표시됨)
            </label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              onBlur={handleNoteBlur}
              placeholder="피부 상태, 특이사항, 귀가 후 관리 팁 등을 입력하세요"
              className="w-full text-xs text-[#374151] bg-[#FAFAFA] border border-[#E8EDE8] rounded-xl p-3 resize-none focus:outline-none focus:border-[#1B4332]/40 leading-relaxed"
              rows={3}
            />
          </div>

          {/* All status buttons */}
          <div>
            <p className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider mb-2">단계 직접 변경</p>
            <div className="flex flex-wrap gap-1.5">
              {STATUS_ORDER.map((s) => {
                const sc = STATUS_COLORS[s];
                const isCurrent = appt.status === s;
                return (
                  <button
                    key={s}
                    onClick={() => !isCurrent && handleStatusChange(s)}
                    disabled={isCurrent}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all hover:scale-105 active:scale-95 disabled:cursor-not-allowed disabled:opacity-70"
                    style={
                      isCurrent
                        ? { background: sc.bg, color: sc.text, border: `2px solid ${sc.bg}` }
                        : { background: sc.light, color: sc.bg, border: `1px solid ${sc.bg}30` }
                    }
                  >
                    {STATUS_ICONS[s]} {STATUS_LABELS[s]}
                    {isCurrent && " ✓"}
                  </button>
                );
              })}
              <button
                onClick={() => handleStatusChange("특이사항있음")}
                disabled={appt.status === "특이사항있음"}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-[#FEE2E2] text-[#DC2626] border border-[#DC262630] hover:scale-105 active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed transition-all"
              >
                ⚠️ 특이사항
              </button>
            </div>
          </div>

          {/* Bottom actions */}
          <div className="flex gap-2 pt-1">
            {isComplete && (
              <Button
                className="flex-1 h-11 text-xs font-bold rounded-xl bg-[#1B4332] text-white shadow-md"
                onClick={() => toast.success("픽업 완료 처리되었습니다")}
              >
                ✅ 픽업 완료
              </Button>
            )}
            <button
              onClick={handleCopyLink}
              className={`flex-1 h-11 rounded-xl border-2 flex items-center justify-center gap-2 text-xs font-bold transition-all ${
                copied
                  ? "bg-[#D1FAE5] border-[#A7F3D0] text-[#065F46]"
                  : "bg-white border-[#E8EDE8] text-[#1B4332] hover:border-[#1B4332]/30 hover:bg-[#F0FDF4]"
              }`}
            >
              {copied ? <Check size={13} /> : <Copy size={13} />}
              {copied ? "복사됨!" : "보호자 링크 복사"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function StaffPage() {
  const [, navigate] = useLocation();
  const { shop } = useShop();
  const shopName = shop?.name ?? "그루밍노트";
  const [filter, setFilter] = useState<"전체" | "진행중" | "완료">("진행중");

  // PIN 인증 상태 확인 (서버 쿠키 기반)
  const { data: authData, isLoading: authLoading } = trpc.staff.isAuthenticated.useQuery();

  useEffect(() => {
    if (!authLoading && authData && !authData.authenticated) {
      navigate("/staff-login");
    }
  }, [authData, authLoading]);

  const { data: appointments = [], isLoading, refetch } = trpc.appointments.listActive.useQuery(
    undefined,
    { refetchInterval: 15000 }
  );

  const activeCount = appointments.filter((a: any) => a.status !== "완료" && a.status !== "특이사항있음").length;
  const completedCount = appointments.filter((a: any) => a.status === "완료").length;
  const specialCount = appointments.filter((a: any) => a.status === "특이사항있음").length;

  const filtered = appointments.filter((a: any) => {
    if (filter === "진행중") return a.status !== "완료";
    if (filter === "완료") return a.status === "완료";
    return true;
  });

  const logoutMutation = trpc.staff.logout.useMutation({
    onSuccess: () => navigate("/staff-login"),
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  if (authLoading) return (
    <div className="min-h-screen bg-[#F4F7F4] flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-[#1B4332]/20 border-t-[#1B4332] rounded-full animate-spin" />
    </div>
  );

  if (!authData?.authenticated) return null;

  return (
    <div className="min-h-screen bg-[#F4F7F4]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-[#E8EDE8] shadow-sm">
        <div className="max-w-2xl mx-auto px-4 flex items-center justify-between h-14">
          <button onClick={() => navigate("/")} className="flex items-center gap-1 text-[#1B4332] text-sm font-medium">
            <ChevronLeft size={18} />홈
          </button>
          <div className="text-center">
            <p className="font-bold text-[#1B4332] text-sm leading-tight">🐾 직원 관리 화면</p>
            <p className="text-[10px] text-[#9CA3AF]">{shopName}</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => refetch()}
              className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[#F0FDF4] text-[#1B4332] transition-all"
            >
              <RefreshCw size={15} />
            </button>
            <button
              onClick={() => navigate("/history")}
              className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[#F0FDF4] text-[#1B4332] transition-all"
              title="접수 이력"
            >
              <History size={15} />
            </button>
            <button
              onClick={handleLogout}
              className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[#FEE2E2] text-[#9CA3AF] hover:text-[#DC2626] transition-all"
              title="로그아웃"
            >
              <LogOut size={15} />
            </button>
            <Button
              size="sm"
              className="bg-[#1B4332] text-white text-xs h-8 px-3 rounded-xl"
              onClick={() => navigate("/checkin?source=staff")}
            >
              <Plus size={13} className="mr-1" />접수
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 py-5 space-y-4">

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white rounded-2xl border border-[#E8EDE8] p-4 shadow-sm text-center">
            <div className="w-9 h-9 rounded-xl bg-[#DBEAFE] flex items-center justify-center mx-auto mb-2">
              <Scissors size={15} className="text-[#1D4ED8]" />
            </div>
            <p className="text-2xl font-bold text-[#1B4332]">{activeCount}</p>
            <p className="text-[10px] text-[#9CA3AF] mt-0.5">진행 중</p>
          </div>
          <div className="bg-white rounded-2xl border border-[#E8EDE8] p-4 shadow-sm text-center">
            <div className="w-9 h-9 rounded-xl bg-[#D1FAE5] flex items-center justify-center mx-auto mb-2">
              <CheckCircle2 size={15} className="text-[#059669]" />
            </div>
            <p className="text-2xl font-bold text-[#1B4332]">{completedCount}</p>
            <p className="text-[10px] text-[#9CA3AF] mt-0.5">완료</p>
          </div>
          <div className="bg-white rounded-2xl border border-[#E8EDE8] p-4 shadow-sm text-center">
            <div className="w-9 h-9 rounded-xl bg-[#FEE2E2] flex items-center justify-center mx-auto mb-2">
              <AlertTriangle size={15} className="text-[#DC2626]" />
            </div>
            <p className="text-2xl font-bold text-[#1B4332]">{specialCount}</p>
            <p className="text-[10px] text-[#9CA3AF] mt-0.5">특이사항</p>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2">
          {(["진행중", "전체", "완료"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`flex-1 h-9 rounded-xl text-xs font-bold transition-all ${
                filter === f
                  ? "bg-[#1B4332] text-white shadow-md"
                  : "bg-white text-[#6B7280] border border-[#E8EDE8] hover:border-[#1B4332]/30"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Appointment Cards */}
        {isLoading ? (
          <div className="bg-white rounded-3xl border border-[#E8EDE8] p-10 text-center shadow-sm">
            <div className="w-8 h-8 border-4 border-[#1B4332]/20 border-t-[#1B4332] rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs text-[#9CA3AF]">불러오는 중...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="bg-white rounded-3xl border border-[#E8EDE8] p-10 text-center shadow-sm">
            <p className="text-4xl mb-3">🐾</p>
            <p className="text-sm font-bold text-[#1B4332] mb-1">해당하는 접수가 없습니다</p>
            <p className="text-xs text-[#9CA3AF]">다른 필터를 선택하거나 새 접수를 추가해보세요</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((appt: any) => (
              <AppointmentCard key={appt.id} appt={appt} onUpdate={() => refetch()} />
            ))}
          </div>
        )}

        {/* Usage guide */}
        <div className="bg-[#1B4332] rounded-3xl p-5 shadow-xl">
          <p className="text-white font-bold text-sm mb-3 flex items-center gap-2">
            📲 보호자 안내 링크 사용법
          </p>
          <ol className="space-y-2">
            {[
              "카드를 탭해서 열고 '보호자 링크 복사' 버튼을 누릅니다",
              "카카오톡 또는 문자로 보호자에게 전송합니다",
              "보호자가 링크를 열면 실시간 상태를 확인합니다",
              "단계가 바뀔 때마다 '다음 단계' 버튼을 눌러주세요",
            ].map((step, i) => (
              <li key={i} className="flex items-start gap-2.5 text-xs text-white/70">
                <span className="w-5 h-5 rounded-full bg-white/20 text-white flex items-center justify-center text-xs flex-shrink-0 font-bold mt-0.5">
                  {i + 1}
                </span>
                {step}
              </li>
            ))}
          </ol>
        </div>

        <div className="h-4" />
      </div>
    </div>
  );
}
