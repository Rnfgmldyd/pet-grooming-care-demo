/**
 * ShopEntryPage - 슬러그 기반 매장 진입 페이지
 * URL: /{slug} 또는 /{slug}/staff 등으로 접속 시 shop_id 쿠키를 설정하고 이동
 *
 * 용도:
 * - 보호자가 /{slug} 접속 → 직원이 공유한 링크 → 접수 페이지
 * - 직원이 /{slug}/staff-login 접속 → 직원 로그인
 */
import { useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

interface ShopEntryProps {
  target?: "staff-login" | "checkin" | "staff";
}

export default function ShopEntryPage({ target = "checkin" }: ShopEntryProps) {
  const [location] = useLocation();
  // /s/:slug/... 형태에서 slug 추출
  const slugMatch = location.match(/^\/s\/([^/]+)/);
  const slug = slugMatch ? slugMatch[1] : null;
  const [, navigate] = useLocation();

  const setSession = trpc.shop.setSession.useMutation({
    onSuccess: (data) => {
      // 세션 설정 완료 후 목적지로 이동 (PIN 인증 비활성화 - staff-login도 /staff로 바로 이동)
      if (target === "staff-login" || target === "staff") {
        navigate("/staff");
      } else {
        navigate("/checkin");
      }
    },
    onError: (err) => {
      toast.error(err.message || "매장을 찾을 수 없습니다");
      navigate("/");
    },
  });

  useEffect(() => {
    if (slug) {
      setSession.mutate({ slug });
    } else {
      navigate("/");
    }
  }, [slug]);

  return (
    <div className="min-h-screen bg-[#F4F7F4] flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#1B4332] mx-auto mb-3" />
        <p className="text-sm text-[#6B7280]">매장 정보를 불러오는 중...</p>
      </div>
    </div>
  );
}
