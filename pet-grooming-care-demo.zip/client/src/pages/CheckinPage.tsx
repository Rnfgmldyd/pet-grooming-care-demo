/**
 * Design: Modern Clinic + Pet Care Brand
 * CheckinPage: 보호자 QR 접수 폼
 * 보호자가 QR코드로 접속해 반려견 정보를 직접 입력하는 화면
 * 접수 완료 후 진행 상황 화면으로 자동 이동
 */
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Check, AlertTriangle, Scissors } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { nanoid } from "nanoid";
import { SHOP, BREEDS, BASE_SERVICES } from "@/lib/shop-config";

// GROOMING_OPTIONS: shop-config의 BASE_SERVICES에서 자동 생성 + 기타 추가
const GROOMING_OPTIONS = [...BASE_SERVICES.map((s) => s.label), "기타"];

const SENSITIVE_OPTIONS = ["귀", "발", "배", "꼬리", "얼굴", "목", "등"];

type Step = 1 | 2 | 3;

export default function CheckinPage() {
  const [location, navigate] = useLocation();
  const [step, setStep] = useState<Step>(1);
  // URL 파라미터로 source 구분: /checkin?source=staff (직원 접수) 또는 기본 (보호자 접수)
  const isStaffMode = new URLSearchParams(window.location.search).get("source") === "staff";
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [newId, setNewId] = useState("");

  // Form state
  const [ownerName, setOwnerName] = useState("");
  const [phone, setPhone] = useState("");
  const [dogName, setDogName] = useState("");
  const [breed, setBreed] = useState("");
  const [customBreed, setCustomBreed] = useState("");
  const [age, setAge] = useState("");
  const [weight, setWeight] = useState("");
  const [groomingRequest, setGroomingRequest] = useState("");
  const [customGrooming, setCustomGrooming] = useState("");
  const [sensitiveParts, setSensitiveParts] = useState<string[]>([]);
  const [skinCondition, setSkinCondition] = useState("정상");
  const [biteRisk, setBiteRisk] = useState(false);
  const [allergy, setAllergy] = useState("");
  const [notes, setNotes] = useState("");
  const [estimatedTime, setEstimatedTime] = useState("약 1시간 30분");

  // ── 재방문 보호자 정보 자동 불러오기 ──
  useEffect(() => {
    try {
      const saved = localStorage.getItem("checkin_owner_profile");
      if (saved) {
        const profile = JSON.parse(saved);
        if (profile.ownerName) setOwnerName(profile.ownerName);
        if (profile.phone) setPhone(profile.phone);
        if (profile.dogName) setDogName(profile.dogName);
        if (profile.breed) setBreed(profile.breed);
        if (profile.age) setAge(profile.age);
        if (profile.weight) setWeight(profile.weight);
      }
      // GroomingSelectPage에서 선택한 스타일 자동 반영
      const styleSelection = localStorage.getItem("grooming_style_selection");
      if (styleSelection) {
        const sel = JSON.parse(styleSelection);
        if (sel.finalLabel) setGroomingRequest(sel.finalLabel);
        localStorage.removeItem("grooming_style_selection"); // 1회 사용 후 삭제
      }
    } catch {}
  }, []);

  // ── 접수 완료 시 보호자 프로필 저장 ──
  const saveOwnerProfile = () => {
    try {
      localStorage.setItem("checkin_owner_profile", JSON.stringify({
        ownerName, phone, dogName,
        breed: breed === "기타" ? customBreed : breed,
        age, weight,
      }));
    } catch {}
  };

  const toggleSensitive = (part: string) => {
    setSensitiveParts((prev) =>
      prev.includes(part) ? prev.filter((p) => p !== part) : [...prev, part]
    );
  };

  const createAppointment = trpc.appointments.create.useMutation();

  const handleSubmit = async () => {
    setSubmitting(true);
    const id = nanoid(8);
    try {
      await createAppointment.mutateAsync({
        id,
        ownerName,
        phone,
        dogName,
        breed: breed === "기타" ? customBreed : breed,
        age: age ? age + "살" : "",
        weight: weight ? weight + "kg" : "",
        groomingRequest: groomingRequest === "기타" ? customGrooming : groomingRequest,
        sensitiveParts,
        skinCondition,
        biteRisk,
        allergy: allergy || "없음",
        notes,
        estimatedTime,
        source: isStaffMode ? "staff" : "owner",
      });
      saveOwnerProfile();
      setNewId(id);
      setDone(true);
    } catch (err: any) {
      console.error(err);
      alert("접수 중 오류가 발생했습니다. 다시 시도해주세요.");
    } finally {
      setSubmitting(false);
    }
  };

  const isStep1Valid = ownerName.trim() && phone.trim() && dogName.trim() && breed;
  const isStep2Valid = groomingRequest && (groomingRequest !== "기타" || customGrooming.trim());

  // ── 완료 화면 ──
  if (done) {
    return (
      <div className="min-h-screen bg-[#F4F7F4] flex flex-col items-center justify-center px-5" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>
        <div className="max-w-sm w-full text-center">
          <div className="w-24 h-24 rounded-3xl bg-[#D1FAE5] flex items-center justify-center text-5xl mx-auto mb-6 shadow-lg">
            🐾
          </div>
          <div className="w-12 h-12 rounded-full bg-[#1B4332] flex items-center justify-center mx-auto -mt-8 mb-6 shadow-md border-4 border-white">
            <Check size={20} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-[#1B4332] mb-2" style={{ fontFamily: "'Noto Serif KR', serif" }}>
            접수 완료!
          </h1>
          <p className="text-[#6B7280] text-sm leading-relaxed mb-8">
            <span className="font-bold text-[#1B4332]">{dogName}</span>의 미용 접수가 완료되었습니다.<br />
            아래 버튼을 눌러 진행 상황을 실시간으로 확인하세요.
          </p>
          <Button
            className="w-full h-14 bg-[#1B4332] text-white font-bold text-sm rounded-2xl shadow-xl mb-3"
            onClick={() => navigate(`/status/${newId}`)}
          >
            🐶 {dogName} 미용 현황 보기 →
          </Button>
          {isStaffMode ? (
            <Button
              variant="outline"
              className="w-full h-12 border-[#E8EDE8] text-[#1B4332] font-bold text-sm rounded-2xl bg-transparent"
              onClick={() => navigate("/staff")}
            >
              ← 직원 관리 화면으로
            </Button>
          ) : (
            <p className="text-xs text-[#9CA3AF]">링크를 저장해두시면 언제든 확인할 수 있습니다</p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F4F7F4]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#E8EDE8] shadow-sm">
        <div className="max-w-lg mx-auto px-4 flex items-center h-14">
          <button onClick={() => step === 1 ? navigate("/") : setStep((s) => (s - 1) as Step)} className="flex items-center gap-1 text-[#1B4332] text-sm font-medium">
            <ChevronLeft size={18} />{step === 1 ? "홈" : "이전"}
          </button>
          <div className="mx-auto text-center">
            <span className="font-bold text-[#1B4332] text-sm block leading-tight">🐾 {SHOP.name}</span>
            <span className="text-[10px] text-[#9CA3AF]">방문 접수</span>
          </div>
          <div className="w-16 text-right">
            <span className="text-xs text-[#9CA3AF] font-medium">{step}/3</span>
          </div>
        </div>
        {/* Progress bar */}
        <div className="h-1 bg-[#F3F4F6]">
          <div
            className="h-full bg-[#1B4332] transition-all duration-500 ease-out"
            style={{ width: `${(step / 3) * 100}%` }}
          />
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 py-6 pb-28">

        {/* ── STEP 1: 기본 정보 ── */}
        {step === 1 && (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-bold text-[#1B4332] mb-1" style={{ fontFamily: "'Noto Serif KR', serif" }}>
                보호자 & 반려견 정보
              </h2>
              <p className="text-sm text-[#9CA3AF]">정확한 미용을 위해 기본 정보를 입력해주세요</p>
            </div>

            {/* 재방문 자동 불러오기 배너 */}
            {ownerName && (
              <div className="bg-[#F0FDF4] rounded-xl border border-[#86EFAC] p-3 flex items-center gap-3">
                <span className="text-xl">👋</span>
                <div className="flex-1">
                  <p className="text-xs font-bold text-[#065F46]">이전 방문 정보를 불러왔어요!</p>
                  <p className="text-[10px] text-[#6B7280] mt-0.5">정보를 확인하고 변경이 필요하면 수정해주세요.</p>
                </div>
                <button
                  onClick={() => {
                    setOwnerName(""); setPhone(""); setDogName("");
                    setBreed(""); setAge(""); setWeight("");
                    localStorage.removeItem("checkin_owner_profile");
                  }}
                  className="text-[10px] text-[#9CA3AF] hover:text-[#DC2626] transition-colors flex-shrink-0"
                >
                  초기화
                </button>
              </div>
            )}

            {/* 보호자 이름 */}
            <div>
              <label className="text-xs font-bold text-[#374151] mb-1.5 block">보호자 이름 <span className="text-[#DC2626]">*</span></label>
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                placeholder="홍길동"
                className="w-full h-12 px-4 rounded-xl border-2 border-[#E8EDE8] focus:border-[#1B4332] focus:outline-none text-sm bg-white transition-colors"
              />
            </div>

            {/* 연락처 */}
            <div>
              <label className="text-xs font-bold text-[#374151] mb-1.5 block">연락처 <span className="text-[#DC2626]">*</span></label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="010-0000-0000"
                className="w-full h-12 px-4 rounded-xl border-2 border-[#E8EDE8] focus:border-[#1B4332] focus:outline-none text-sm bg-white transition-colors"
              />
            </div>

            {/* 반려견 이름 */}
            <div>
              <label className="text-xs font-bold text-[#374151] mb-1.5 block">반려견 이름 <span className="text-[#DC2626]">*</span></label>
              <input
                type="text"
                value={dogName}
                onChange={(e) => setDogName(e.target.value)}
                placeholder="초코, 보리, 두부..."
                className="w-full h-12 px-4 rounded-xl border-2 border-[#E8EDE8] focus:border-[#1B4332] focus:outline-none text-sm bg-white transition-colors"
              />
            </div>

            {/* 견종 */}
            <div>
              <label className="text-xs font-bold text-[#374151] mb-2 block">견종 <span className="text-[#DC2626]">*</span></label>
              <div className="grid grid-cols-3 gap-2">
                {BREEDS.map((b) => (
                  <button
                    key={b}
                    onClick={() => setBreed(b)}
                    className={`h-10 rounded-xl text-xs font-bold transition-all border-2 ${
                      breed === b
                        ? "bg-[#1B4332] text-white border-[#1B4332]"
                        : "bg-white text-[#374151] border-[#E8EDE8] hover:border-[#1B4332]/40"
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
              {breed === "기타" && (
                <input
                  type="text"
                  value={customBreed}
                  onChange={(e) => setCustomBreed(e.target.value)}
                  placeholder="견종을 직접 입력해주세요"
                  className="w-full h-11 px-4 mt-2 rounded-xl border-2 border-[#1B4332]/40 focus:border-[#1B4332] focus:outline-none text-sm bg-white"
                />
              )}
            </div>

            {/* 나이 & 몸무게 */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-[#374151] mb-1.5 block">나이 (살)</label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="3"
                  min="0"
                  max="20"
                  className="w-full h-12 px-4 rounded-xl border-2 border-[#E8EDE8] focus:border-[#1B4332] focus:outline-none text-sm bg-white"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-[#374151] mb-1.5 block">몸무게 (kg)</label>
                <input
                  type="number"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  placeholder="3.5"
                  step="0.1"
                  min="0"
                  className="w-full h-12 px-4 rounded-xl border-2 border-[#E8EDE8] focus:border-[#1B4332] focus:outline-none text-sm bg-white"
                />
              </div>
            </div>
          </div>
        )}

        {/* ── STEP 2: 미용 요청 ── */}
        {step === 2 && (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-bold text-[#1B4332] mb-1" style={{ fontFamily: "'Noto Serif KR', serif" }}>
                미용 요청사항
              </h2>
              <p className="text-sm text-[#9CA3AF]">원하시는 미용 스타일과 주의사항을 알려주세요</p>
            </div>

            {/* 미용 종류 */}
            <div>
              <label className="text-xs font-bold text-[#374151] mb-2 block">미용 종류 <span className="text-[#DC2626]">*</span></label>

              {/* 이미지 선택 배너 */}
              <button
                onClick={() => navigate("/grooming-select")}
                className="w-full mb-3 flex items-center gap-3 bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] rounded-2xl p-3.5 text-left hover:opacity-95 active:scale-[0.99] transition-all shadow-md"
              >
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                  <Scissors size={18} className="text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-white font-bold text-sm leading-tight">🐾 이미지로 스타일 선택하기</p>
                  <p className="text-white/70 text-[10px] mt-0.5">곰돌이컷, 스포팅, 가위컷 등 사진 보고 선택</p>
                </div>
                <div className="text-white/60">
                  <ChevronRight size={16} />
                </div>
              </button>

              <p className="text-[10px] text-[#9CA3AF] mb-2 text-center">— 또는 아래에서 직접 선택 —</p>

              <div className="space-y-2">
                {GROOMING_OPTIONS.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => setGroomingRequest(opt)}
                    className={`w-full flex items-center justify-between h-12 px-4 rounded-xl text-sm font-medium transition-all border-2 ${
                      groomingRequest === opt
                        ? "bg-[#F0FDF4] text-[#1B4332] border-[#1B4332]"
                        : "bg-white text-[#374151] border-[#E8EDE8] hover:border-[#1B4332]/30"
                    }`}
                  >
                    {opt}
                    {groomingRequest === opt && <Check size={16} className="text-[#1B4332]" />}
                  </button>
                ))}
              </div>
              {groomingRequest === "기타" && (
                <input
                  type="text"
                  value={customGrooming}
                  onChange={(e) => setCustomGrooming(e.target.value)}
                  placeholder="원하시는 미용을 직접 입력해주세요"
                  className="w-full h-11 px-4 mt-2 rounded-xl border-2 border-[#1B4332]/40 focus:border-[#1B4332] focus:outline-none text-sm bg-white"
                />
              )}
            </div>

            {/* 예민한 부위 */}
            <div>
              <label className="text-xs font-bold text-[#374151] mb-2 block">예민한 부위 (복수 선택 가능)</label>
              <div className="flex flex-wrap gap-2">
                {SENSITIVE_OPTIONS.map((part) => (
                  <button
                    key={part}
                    onClick={() => toggleSensitive(part)}
                    className={`h-9 px-4 rounded-xl text-xs font-bold transition-all border-2 ${
                      sensitiveParts.includes(part)
                        ? "bg-[#FEE2E2] text-[#DC2626] border-[#FCA5A5]"
                        : "bg-white text-[#6B7280] border-[#E8EDE8] hover:border-[#FCA5A5]"
                    }`}
                  >
                    {sensitiveParts.includes(part) ? "⚠️ " : ""}{part}
                  </button>
                ))}
              </div>
            </div>

            {/* 피부 상태 */}
            <div>
              <label className="text-xs font-bold text-[#374151] mb-2 block">피부 상태</label>
              <div className="grid grid-cols-3 gap-2">
                {["정상", "건조", "예민", "피부병 있음", "알레르기", "기타"].map((s) => (
                  <button
                    key={s}
                    onClick={() => setSkinCondition(s)}
                    className={`h-10 rounded-xl text-xs font-bold transition-all border-2 ${
                      skinCondition === s
                        ? "bg-[#1B4332] text-white border-[#1B4332]"
                        : "bg-white text-[#374151] border-[#E8EDE8] hover:border-[#1B4332]/40"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* 입질 여부 */}
            <div className={`rounded-2xl border-2 p-4 transition-all ${biteRisk ? "bg-[#FEF3C7] border-[#FDE68A]" : "bg-white border-[#E8EDE8]"}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <AlertTriangle size={18} className={biteRisk ? "text-[#D97706]" : "text-[#9CA3AF]"} />
                  <div>
                    <p className="text-sm font-bold text-[#374151]">입질 주의</p>
                    <p className="text-xs text-[#9CA3AF]">낯선 사람에게 예민하거나 물 수 있는 경우</p>
                  </div>
                </div>
                <button
                  onClick={() => setBiteRisk(!biteRisk)}
                  className={`w-12 h-6 rounded-full transition-all duration-200 relative ${biteRisk ? "bg-[#D97706]" : "bg-[#E5E7EB]"}`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white shadow-sm absolute top-0.5 transition-all duration-200 ${biteRisk ? "left-6" : "left-0.5"}`} />
                </button>
              </div>
            </div>

            {/* 알레르기 */}
            <div>
              <label className="text-xs font-bold text-[#374151] mb-1.5 block">알레르기 / 특이 반응</label>
              <input
                type="text"
                value={allergy}
                onChange={(e) => setAllergy(e.target.value)}
                placeholder="없음 또는 특이 반응이 있다면 입력해주세요"
                className="w-full h-12 px-4 rounded-xl border-2 border-[#E8EDE8] focus:border-[#1B4332] focus:outline-none text-sm bg-white"
              />
            </div>
          </div>
        )}

        {/* ── STEP 3: 추가 요청 & 확인 ── */}
        {step === 3 && (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-bold text-[#1B4332] mb-1" style={{ fontFamily: "'Noto Serif KR', serif" }}>
                추가 요청 & 최종 확인
              </h2>
              <p className="text-sm text-[#9CA3AF]">추가 요청사항을 입력하고 내용을 확인해주세요</p>
            </div>

            {/* 추가 메모 */}
            <div>
              <label className="text-xs font-bold text-[#374151] mb-1.5 block">추가 요청사항</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="예: 귀 쪽 조심해주세요. 드라이 소리를 무서워해요. 꼬리는 짧게 해주세요..."
                className="w-full px-4 py-3 rounded-xl border-2 border-[#E8EDE8] focus:border-[#1B4332] focus:outline-none text-sm bg-white resize-none leading-relaxed"
                rows={4}
              />
            </div>

            {/* 접수 내용 요약 */}
            <div className="bg-white rounded-2xl border-2 border-[#E8EDE8] overflow-hidden shadow-sm">
              <div className="px-4 py-3 bg-[#F0FDF4] border-b border-[#D1FAE5] flex items-center gap-2">
                <span className="text-sm">📋</span>
                <h3 className="text-xs font-bold text-[#1B4332] uppercase tracking-wider">접수 내용 확인</h3>
              </div>
              <div className="px-4 py-4 space-y-2.5">
                {[
                  { label: "보호자", value: `${ownerName} (${phone})` },
                  { label: "반려견", value: `${dogName} · ${breed === "기타" ? customBreed : breed} · ${age}살 · ${weight}kg` },
                  { label: "미용 요청", value: groomingRequest === "기타" ? customGrooming : groomingRequest },
                  { label: "피부 상태", value: skinCondition },
                  ...(sensitiveParts.length > 0 ? [{ label: "예민 부위", value: sensitiveParts.join(", ") }] : []),
                  ...(biteRisk ? [{ label: "입질 주의", value: "⚠️ 예" }] : []),
                  ...(allergy ? [{ label: "알레르기", value: allergy }] : []),
                  ...(notes ? [{ label: "추가 메모", value: notes }] : []),
                ].map((row, i) => (
                  <div key={i} className="flex items-start justify-between gap-3">
                    <span className="text-xs text-[#9CA3AF] flex-shrink-0 pt-0.5">{row.label}</span>
                    <span className="text-xs font-bold text-[#1B4332] text-right leading-relaxed">{row.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 동의 안내 */}
            <div className="bg-[#FAFAFA] rounded-xl border border-[#E8EDE8] p-4">
              <p className="text-xs text-[#9CA3AF] leading-relaxed">
                접수 완료 후 담당 선생님이 확인하고 미용을 시작합니다. 진행 상황은 링크로 실시간 확인하실 수 있습니다.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Fixed Bottom CTA */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-[#E8EDE8] px-4 py-4 shadow-lg">
        <div className="max-w-lg mx-auto">
          {step < 3 ? (
            <Button
              className="w-full h-14 bg-[#1B4332] text-white font-bold text-sm rounded-2xl shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={step === 1 ? !isStep1Valid : !isStep2Valid}
              onClick={() => setStep((s) => (s + 1) as Step)}
            >
              다음 단계 <ChevronRight size={16} className="ml-1" />
            </Button>
          ) : (
            <Button
              className="w-full h-14 font-bold text-sm rounded-2xl shadow-xl"
              style={{ background: "linear-gradient(135deg, #1B4332, #065F46)", color: "white" }}
              onClick={handleSubmit}
              disabled={submitting}
            >
              {submitting ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  접수 중...
                </span>
              ) : (
                <>🐾 접수 완료하기</>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
