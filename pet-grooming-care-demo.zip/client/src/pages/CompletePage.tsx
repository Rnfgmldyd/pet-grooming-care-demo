/**
 * Design: Modern Clinic + Pet Care Brand
 * CompletePage v4: 보호자용 미용 완료 안내 화면 - 상품성 강화
 * 미용 완료 사진 첨부 UI + 강화된 리뷰 유도 + 완료 시간 + 재방문 CTA
 */
import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft, Phone, Star, Calendar, Heart, CheckCircle2, Camera, Upload, Share2, ExternalLink } from "lucide-react";
import { getAppointmentById, type Appointment } from "@/lib/store";
import { SHOP, AFTER_CARE } from "@/lib/shop-config";

const afterCareItems = AFTER_CARE;

function formatCompletedTime(iso?: string): string {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleString("ko-KR", {
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function CompletePage() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const [appt, setAppt] = useState<Appointment | undefined>(undefined);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [reviewText, setReviewText] = useState("");
  const [reviewSubmitted, setReviewSubmitted] = useState(false);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [confetti, setConfetti] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const data = getAppointmentById(id || "demo-003");
    setAppt(data);
    // 완료 사진이 있으면 미리보기 설정
    if (data?.completedPhoto) {
      setPhotoPreview(data.completedPhoto);
    }
    // 3초 후 confetti 효과 종료
    const t = setTimeout(() => setConfetti(false), 3000);
    return () => clearTimeout(t);
  }, [id]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setPhotoPreview(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleReviewSubmit = () => {
    if (rating === 0) return;
    setReviewSubmitted(true);
  };

  if (!appt) {
    return (
      <div className="min-h-screen bg-[#FAFAF7] flex items-center justify-center" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>
        <div className="text-center px-6">
          <p className="text-5xl mb-4">🐾</p>
          <p className="text-[#1B4332] font-bold text-lg mb-2">예약 정보를 찾을 수 없습니다</p>
          <Button className="mt-4 bg-[#1B4332] text-white rounded-xl" onClick={() => navigate("/")}>홈으로</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F4F7F4]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#E8EDE8]">
        <div className="max-w-lg mx-auto px-4 flex items-center h-14">
          <button onClick={() => navigate("/")} className="flex items-center gap-1 text-[#1B4332] text-sm font-medium">
            <ChevronLeft size={18} />홈
          </button>
          <div className="mx-auto text-center">
            <span className="font-bold text-[#1B4332] text-sm block leading-tight">{SHOP.logoEmoji} {SHOP.name}</span>
            <span className="text-[10px] text-[#9CA3AF]">미용 완료</span>
          </div>
          <button
            onClick={() => {
              if (navigator.share) {
                navigator.share({ title: `${appt.dogName} 미용 완료`, url: window.location.href });
              }
            }}
            className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[#F0FDF4] text-[#1B4332] transition-all"
          >
            <Share2 size={15} />
          </button>
        </div>
      </header>

      {/* Completion Hero */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[#1B4332] via-[#2D6A4F] to-[#065F46] px-5 pt-10 pb-20">
        {/* Confetti-like decorative elements */}
        {confetti && (
          <>
            <div className="absolute top-4 left-8 text-2xl animate-bounce" style={{ animationDelay: "0ms" }}>🎊</div>
            <div className="absolute top-8 right-12 text-xl animate-bounce" style={{ animationDelay: "200ms" }}>✨</div>
            <div className="absolute top-2 right-6 text-2xl animate-bounce" style={{ animationDelay: "400ms" }}>🎉</div>
            <div className="absolute top-12 left-16 text-lg animate-bounce" style={{ animationDelay: "600ms" }}>⭐</div>
          </>
        )}
        <div className="absolute -top-8 -right-8 w-36 h-36 rounded-full bg-white/5" />
        <div className="absolute -bottom-14 -left-6 w-48 h-48 rounded-full bg-white/5" />

        <div className="relative max-w-lg mx-auto text-center">
          {/* Animated celebration */}
          <div className="flex justify-center gap-4 mb-5 text-3xl">
            <span className="animate-bounce" style={{ animationDelay: "0ms", animationDuration: "1s" }}>🎊</span>
            <span className="animate-bounce" style={{ animationDelay: "200ms", animationDuration: "1s" }}>✨</span>
            <span className="animate-bounce" style={{ animationDelay: "400ms", animationDuration: "1s" }}>🎉</span>
          </div>

          {/* Dog avatar */}
          <div className="w-24 h-24 rounded-2xl bg-white/20 flex items-center justify-center text-6xl border-2 border-white/30 shadow-xl mx-auto mb-4">
            🐶
          </div>

          <h1 className="text-3xl font-bold text-white mb-2 leading-tight" style={{ fontFamily: "'Noto Serif KR', serif" }}>
            {appt.dogName} 미용 완료!
          </h1>
          <p className="text-white/75 text-sm leading-relaxed mb-2">
            오늘도 {SHOP.name}을 이용해 주셔서 감사합니다.<br />
            <span className="text-[#6EE7B7] font-semibold">{appt.dogName}</span>이(가) 예쁘게 단장되었어요 ✨
          </p>

          {/* Completed time */}
          {appt.completedAt && (
            <p className="text-white/40 text-xs mb-4">
              완료 시각: {formatCompletedTime(appt.completedAt)}
            </p>
          )}

          {/* Quick chips */}
          <div className="flex justify-center gap-2 flex-wrap">
            <span className="bg-white/15 text-white text-xs px-3 py-1.5 rounded-full border border-white/20 font-medium">{appt.breed}</span>
            <span className="bg-white/15 text-white text-xs px-3 py-1.5 rounded-full border border-white/20 font-medium">{appt.groomingRequest}</span>
            <span className="bg-[#6EE7B7]/20 text-[#6EE7B7] text-xs px-3 py-1.5 rounded-full border border-[#6EE7B7]/30 font-bold">
              피부 {appt.skinCondition}
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 -mt-10 pb-10 space-y-4">

        {/* Pickup Urgent Notice */}
        <div className="bg-white border-2 border-[#FCA5A5] rounded-2xl p-4 shadow-md">
          <div className="flex items-start gap-3">
            <div className="w-11 h-11 rounded-xl bg-[#FEE2E2] flex items-center justify-center text-xl flex-shrink-0">
              🚗
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1.5">
                <h3 className="font-bold text-[#DC2626] text-sm">픽업 안내</h3>
                <a href={`tel:${SHOP.phone}`} className="flex items-center gap-1 bg-[#DC2626] text-white text-xs font-bold px-3 py-1.5 rounded-xl">
                  <Phone size={11} />전화
                </a>
              </div>
              <p className="text-xs text-[#7F1D1D] leading-relaxed mb-2">
                미용이 완료되었습니다. 가능한 빠른 시간 내 픽업을 부탁드립니다.
                완료 후 1시간 이상 경과 시 추가 보호 비용이 발생할 수 있습니다.
              </p>
              <p className="text-sm font-bold text-[#DC2626]">📱 {SHOP.phone}</p>
            </div>
          </div>
        </div>

        {/* ── 미용 완료 사진 (프로 플랜 기능) ── */}
        <div className="bg-white rounded-2xl border-2 border-[#D1FAE5] shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-[#F0FDF4] bg-[#F0FDF4] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Camera size={14} className="text-[#059669]" />
              <h3 className="text-xs font-bold text-[#065F46] uppercase tracking-wider">미용 완료 사진</h3>
            </div>
            <span className="text-[9px] bg-[#1B4332] text-white px-2 py-0.5 rounded-full font-bold">PRO</span>
          </div>

          {photoPreview ? (
            <div className="relative">
              <img
                src={photoPreview}
                alt="미용 완료 사진"
                className="w-full aspect-square object-cover"
              />
              <div className="absolute bottom-3 right-3">
                <button
                  onClick={() => setPhotoPreview(null)}
                  className="bg-black/50 text-white text-xs px-3 py-1.5 rounded-xl backdrop-blur-sm"
                >
                  변경
                </button>
              </div>
              <div className="absolute top-3 left-3 bg-[#1B4332]/80 text-white text-xs px-2.5 py-1 rounded-xl backdrop-blur-sm flex items-center gap-1">
                <CheckCircle2 size={11} />
                {appt.dogName} 완료 사진
              </div>
            </div>
          ) : (
            <div className="p-5">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-[#A7F3D0] rounded-2xl p-8 flex flex-col items-center justify-center gap-3 cursor-pointer hover:bg-[#F0FDF4] transition-colors"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#D1FAE5] flex items-center justify-center">
                  <Upload size={22} className="text-[#059669]" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-bold text-[#1B4332] mb-1">미용 완료 사진 첨부</p>
                  <p className="text-xs text-[#9CA3AF]">담당자가 촬영한 사진을 보호자에게 전달합니다</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 bg-[#F0FDF4] border border-[#A7F3D0] rounded-xl px-3 py-1.5">
                    <Camera size={12} className="text-[#059669]" />
                    <span className="text-xs font-bold text-[#059669]">사진 선택</span>
                  </div>
                </div>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handlePhotoUpload}
              />
              <p className="text-center text-[10px] text-[#9CA3AF] mt-2">
                * 데모 화면입니다. 실제 납품 시 직원이 사진을 업로드하면 보호자 화면에 즉시 표시됩니다.
              </p>
            </div>
          )}
        </div>

        {/* Today's Report */}
        <div className="bg-white rounded-2xl border border-[#E8EDE8] shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-[#F3F4F6] bg-[#FAFAFA] flex items-center gap-2">
            <span>📋</span>
            <h3 className="text-xs font-bold text-[#6B7280] uppercase tracking-wider">오늘의 미용 리포트</h3>
          </div>
          <div className="px-4 py-4 space-y-3">
            {[
              { label: "반려견", value: `${appt.dogName} (${appt.breed})`, valueClass: "text-[#1B4332] font-bold" },
              { label: "미용 내용", value: appt.groomingRequest, valueClass: "bg-[#F0FDF4] text-[#1B4332] font-bold px-2.5 py-1 rounded-full border border-[#D1FAE5]" },
              { label: "피부 상태", value: appt.skinCondition, valueClass: "bg-[#D1FAE5] text-[#065F46] font-bold px-2.5 py-1 rounded-full" },
            ].map((row, i) => (
              <div key={i} className="flex items-center justify-between">
                <span className="text-xs text-[#9CA3AF]">{row.label}</span>
                <span className={`text-xs ${row.valueClass}`}>{row.value}</span>
              </div>
            ))}
            {appt.staffNote && (
              <div className="pt-2 border-t border-[#F3F4F6]">
                <p className="text-xs text-[#6B7280] mb-2 font-medium">💬 담당자 메모</p>
                <div className="bg-[#F0FDF4] rounded-xl px-3 py-3 border border-[#A7F3D0]">
                  <p className="text-xs text-[#1B4332] leading-relaxed">{appt.staffNote}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* After Care */}
        <div className="bg-white rounded-2xl border border-[#E8EDE8] shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-[#F3F4F6] bg-[#FAFAFA] flex items-center gap-2">
            <span>🏠</span>
            <h3 className="text-xs font-bold text-[#6B7280] uppercase tracking-wider">귀가 후 관리 팁</h3>
          </div>
          {afterCareItems.map((item, i) => (
            <div key={i} className={`px-4 py-3.5 flex items-start gap-3 ${i < afterCareItems.length - 1 ? "border-b border-[#F9FAFB]" : ""}`}>
              <span className="text-xl flex-shrink-0 mt-0.5">{item.icon}</span>
              <div>
                <p className="text-xs font-bold text-[#1B4332] mb-0.5">{item.title}</p>
                <p className="text-xs text-[#6B7280] leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* ── 강화된 리뷰 섹션 ── */}
        <div className="bg-white rounded-2xl border border-[#E8EDE8] shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-[#F3F4F6] bg-[#FAFAFA] flex items-center gap-2">
            <Heart size={14} className="text-[#DC2626] fill-[#DC2626]" />
            <h3 className="text-xs font-bold text-[#6B7280] uppercase tracking-wider">오늘 미용 후기</h3>
          </div>

          {reviewSubmitted ? (
            <div className="p-6 text-center">
              <div className="w-14 h-14 rounded-2xl bg-[#D1FAE5] flex items-center justify-center text-3xl mx-auto mb-3">
                🙏
              </div>
              <p className="font-bold text-[#1B4332] mb-1">소중한 후기 감사합니다!</p>
              <p className="text-xs text-[#6B7280]">더 나은 서비스로 보답하겠습니다.</p>
              <div className="flex gap-0.5 justify-center mt-3">
                {Array.from({ length: rating }).map((_, j) => (
                  <Star key={j} size={18} className="text-[#F59E0B] fill-[#F59E0B]" />
                ))}
              </div>
            </div>
          ) : (
            <div className="p-5">
              <p className="text-sm text-[#374151] mb-4 text-center">
                <span className="font-bold text-[#1B4332]">{appt.dogName}</span>의 미용은 어떠셨나요?
              </p>

              {/* Star rating */}
              <div className="flex justify-center gap-2 mb-4">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    onClick={() => setRating(star)}
                    className="transition-transform duration-100 hover:scale-125 active:scale-110"
                  >
                    <Star
                      size={36}
                      className={`transition-colors duration-150 ${
                        star <= (hoverRating || rating)
                          ? "text-[#F59E0B] fill-[#F59E0B]"
                          : "text-[#E5E7EB] fill-[#E5E7EB]"
                      }`}
                    />
                  </button>
                ))}
              </div>

              {rating > 0 && (
                <p className="text-center text-sm font-medium text-[#1B4332] mb-3">
                  {rating === 5 ? "⭐ 최고예요! 감사합니다 🙏" : rating >= 3 ? "감사합니다! 더 노력하겠습니다 😊" : "소중한 의견 감사합니다. 개선하겠습니다 🙏"}
                </p>
              )}

              {rating > 0 && (
                <textarea
                  value={reviewText}
                  onChange={(e) => setReviewText(e.target.value)}
                  placeholder="미용 후기를 남겨주세요 (선택사항)"
                  className="w-full text-sm text-[#374151] bg-[#FAFAFA] border border-[#E8EDE8] rounded-xl p-3 resize-none focus:outline-none focus:border-[#1B4332]/40 leading-relaxed mb-3"
                  rows={3}
                />
              )}

              <Button
                onClick={handleReviewSubmit}
                disabled={rating === 0}
                className="w-full h-11 bg-[#1B4332] text-white font-bold text-sm rounded-xl disabled:opacity-40 mb-3"
              >
                후기 남기기
              </Button>

              {/* External review links */}
              <div className="grid grid-cols-2 gap-2">
                <a
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className="flex items-center justify-center gap-1.5 h-10 rounded-xl border-2 border-[#E8EDE8] text-xs font-bold text-[#4B5563] hover:border-[#1B4332]/30 hover:text-[#1B4332] transition-all"
                >
                  <ExternalLink size={12} />
                  네이버 리뷰
                </a>
                <a
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className="flex items-center justify-center gap-1.5 h-10 rounded-xl border-2 border-[#E8EDE8] text-xs font-bold text-[#4B5563] hover:border-[#F59E0B]/50 hover:text-[#D97706] transition-all"
                >
                  <ExternalLink size={12} />
                  카카오 리뷰
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Next Visit */}
        <div className="bg-[#1B4332] rounded-2xl p-5 shadow-md">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-11 h-11 rounded-xl bg-white/15 flex items-center justify-center flex-shrink-0">
              <Calendar size={18} className="text-white" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm mb-1">다음 방문 권장</h3>
              <p className="text-xs text-white/65 leading-relaxed">
                털 상태에 따라 <strong className="text-[#6EE7B7]">4~6주 후</strong> 재방문을 권장합니다.
                지금 예약하시면 원하는 시간을 확보할 수 있습니다.
              </p>
            </div>
          </div>
          <div className="space-y-2 mb-4">
            {["다음 방문 시 5% 할인 쿠폰 제공", "단골 고객 우선 예약 혜택"].map((benefit, i) => (
              <div key={i} className="flex items-center gap-2">
                <CheckCircle2 size={13} className="text-[#6EE7B7] flex-shrink-0" />
                <p className="text-xs text-white/75">{benefit}</p>
              </div>
            ))}
          </div>
          <Button className="w-full bg-white text-[#1B4332] hover:bg-[#F0FDF4] font-bold text-sm h-11 rounded-xl">
            다음 예약 문의하기 →
          </Button>
        </div>

        <Button
          variant="outline"
          className="w-full h-11 text-sm border-[#E8EDE8] text-[#6B7280] hover:border-[#1B4332] hover:text-[#1B4332] bg-transparent rounded-xl"
          onClick={() => navigate("/")}
        >
          홈으로 돌아가기
        </Button>
      </div>
    </div>
  );
}
