/**
 * Design: Modern Clinic + Pet Care Brand
 * GroomingSelectPage v2: shop-config.ts 기반 리팩터링
 * 모든 컷 종류, 이미지, 설명, 가격은 shop-config.ts에서 가져옵니다.
 * 납품 시 shop-config.ts 만 수정하면 이 화면이 자동으로 업데이트됩니다.
 */
import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft, Check, Info, ArrowRight, Scissors } from "lucide-react";
import {
  SHOP,
  BASE_SERVICES,
  CUT_TYPES,
  SCISSOR_STYLES,
  type BaseService,
  type CutType,
  type ScissorStyle,
} from "@/lib/shop-config";

type Step = "base" | "cut" | "scissor" | "summary";

export default function GroomingSelectPage() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState<Step>("base");
  const [selectedBase, setSelectedBase] = useState<BaseService | null>(null);
  const [selectedCut, setSelectedCut] = useState<CutType | null>(null);
  const [selectedScissor, setSelectedScissor] = useState<ScissorStyle | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const stepIndex: Record<Step, number> = { base: 0, cut: 1, scissor: 2, summary: 3 };

  const handleBaseSelect = (svc: BaseService) => {
    setSelectedBase(svc);
    setSelectedCut(null);
    setSelectedScissor(null);
  };

  const handleBaseNext = () => {
    if (!selectedBase) return;
    setStep(selectedBase.hasCut ? "cut" : "summary");
  };

  const handleCutSelect = (cut: CutType) => {
    setSelectedCut(cut);
    setSelectedScissor(null);
  };

  const handleCutNext = () => {
    if (!selectedCut) return;
    setStep(selectedCut.hasScissorStyle ? "scissor" : "summary");
  };

  const handleBack = () => {
    if (step === "base") navigate("/checkin");
    else if (step === "cut") setStep("base");
    else if (step === "scissor") setStep("cut");
    else if (step === "summary") {
      if (selectedCut?.hasScissorStyle) setStep("scissor");
      else if (selectedBase?.hasCut) setStep("cut");
      else setStep("base");
    }
  };

  const getFinalLabel = () => {
    if (!selectedBase) return "";
    if (!selectedBase.hasCut) return selectedBase.label;
    if (!selectedCut) return selectedBase.label;
    if (selectedCut.hasScissorStyle && selectedScissor)
      return `${selectedBase.label} + ${selectedScissor.label}`;
    return `${selectedBase.label} + ${selectedCut.label}`;
  };

  return (
    <div className="min-h-screen bg-[#F4F7F4]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#E8EDE8] shadow-sm">
        <div className="max-w-lg mx-auto px-4 flex items-center h-14">
          <button onClick={handleBack} className="flex items-center gap-1 text-[#1B4332] text-sm font-medium">
            <ChevronLeft size={18} />이전
          </button>
          <div className="mx-auto text-center">
            <span className="font-bold text-[#1B4332] text-sm block leading-tight">🐾 미용 스타일 선택</span>
            <span className="text-[10px] text-[#9CA3AF]">{SHOP.name}</span>
          </div>
          <div className="w-16" />
        </div>

        {/* Step indicator */}
        <div className="px-4 pb-3 pt-1">
          <div className="flex items-center gap-1 max-w-lg mx-auto">
            {["기본 서비스", "컷 종류", "가위컷", "확인"].map((label, i) => {
              const isActive = stepIndex[step] === i;
              const isDone = stepIndex[step] > i;
              return (
                <div key={i} className="flex items-center gap-1 flex-1">
                  <div className={`flex items-center gap-1 ${i > 0 ? "flex-1" : ""}`}>
                    {i > 0 && <div className={`h-0.5 flex-1 rounded-full transition-all ${isDone ? "bg-[#1B4332]" : "bg-[#E5E7EB]"}`} />}
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold flex-shrink-0 transition-all ${
                      isActive ? "bg-[#1B4332] text-white scale-110" : isDone ? "bg-[#D1FAE5] text-[#1B4332]" : "bg-[#F3F4F6] text-[#9CA3AF]"
                    }`}>
                      {isDone ? <Check size={10} /> : i + 1}
                    </div>
                  </div>
                  <span className={`text-[9px] font-medium flex-shrink-0 ${isActive ? "text-[#1B4332]" : isDone ? "text-[#059669]" : "text-[#9CA3AF]"}`}>
                    {label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 py-5 pb-32">

        {/* ── STEP: 기본 서비스 ── */}
        {step === "base" && (
          <div>
            <div className="mb-5">
              <h2 className="text-xl font-bold text-[#1B4332] mb-1" style={{ fontFamily: "'Noto Serif KR', serif" }}>
                어떤 미용을 원하시나요?
              </h2>
              <p className="text-sm text-[#9CA3AF]">기본 서비스를 먼저 선택해주세요</p>
            </div>

            <div className="space-y-3">
              {BASE_SERVICES.map((svc) => {
                const isSelected = selectedBase?.id === svc.id;
                const isExpanded = expandedId === svc.id;
                return (
                  <div key={svc.id} className={`rounded-2xl border-2 overflow-hidden transition-all duration-200 ${
                    isSelected ? `${svc.bgColor} ${svc.borderColor} shadow-md` : "bg-white border-[#E8EDE8]"
                  }`}>
                    <button className="w-full flex items-center gap-3 p-3 text-left" onClick={() => handleBaseSelect(svc)}>
                      <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 bg-[#F3F4F6]">
                        <img src={svc.img} alt={svc.label} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-bold text-[#1B4332]">{svc.emoji} {svc.label}</span>
                          {svc.hasCut && (
                            <span className="text-[9px] bg-[#1B4332] text-white px-1.5 py-0.5 rounded-full font-bold flex-shrink-0">스타일 선택</span>
                          )}
                        </div>
                        <p className="text-xs text-[#6B7280] mb-1.5">{svc.desc}</p>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] bg-[#F0FDF4] text-[#059669] px-2 py-0.5 rounded-full font-medium">⏱ {svc.time}</span>
                          <span className="text-[10px] bg-[#FEF9C3] text-[#92400E] px-2 py-0.5 rounded-full font-medium">💰 {svc.price}</span>
                        </div>
                      </div>
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                        isSelected ? "bg-[#1B4332] border-[#1B4332]" : "border-[#D1D5DB]"
                      }`}>
                        {isSelected && <Check size={13} className="text-white" />}
                      </div>
                    </button>
                    <div className="px-3 pb-2">
                      <button onClick={() => setExpandedId(isExpanded ? null : svc.id)}
                        className="flex items-center gap-1 text-[10px] text-[#9CA3AF] hover:text-[#1B4332] transition-colors">
                        <Info size={11} />{isExpanded ? "접기" : "자세히 보기"}
                      </button>
                      {isExpanded && (
                        <div className="mt-2 bg-white/70 rounded-xl p-3 border border-[#E8EDE8]">
                          <p className="text-xs text-[#374151] leading-relaxed">{svc.detail}</p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── STEP: 컷 종류 ── */}
        {step === "cut" && (
          <div>
            <div className="mb-5">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs bg-[#D1FAE5] text-[#065F46] px-2 py-0.5 rounded-full font-bold">{selectedBase?.label}</span>
              </div>
              <h2 className="text-xl font-bold text-[#1B4332] mb-1" style={{ fontFamily: "'Noto Serif KR', serif" }}>
                어떤 컷 스타일로 해드릴까요?
              </h2>
              <p className="text-sm text-[#9CA3AF]">이미지를 참고해 원하는 스타일을 선택해주세요</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {CUT_TYPES.map((cut) => {
                const isSelected = selectedCut?.id === cut.id;
                const isExpanded = expandedId === cut.id;
                return (
                  <div key={cut.id} className={`rounded-2xl border-2 overflow-hidden transition-all duration-200 ${
                    isSelected ? `${cut.bgColor} ${cut.borderColor} shadow-md` : "bg-white border-[#E8EDE8]"
                  }`}>
                    <button className="w-full text-left" onClick={() => handleCutSelect(cut)}>
                      <div className="relative w-full aspect-square overflow-hidden bg-[#F3F4F6]">
                        <img src={cut.img} alt={cut.label} className="w-full h-full object-cover" />
                        {isSelected && (
                          <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-[#1B4332] flex items-center justify-center shadow-md">
                            <Check size={13} className="text-white" />
                          </div>
                        )}
                        {cut.hasScissorStyle && (
                          <div className="absolute bottom-2 left-2 bg-[#7C3AED]/80 text-white text-[9px] px-2 py-0.5 rounded-full font-bold backdrop-blur-sm flex items-center gap-1">
                            <Scissors size={9} />스타일 선택
                          </div>
                        )}
                      </div>
                      <div className="p-2.5">
                        <p className="text-xs font-bold text-[#1B4332] mb-1">{cut.label}</p>
                        <p className="text-[10px] text-[#6B7280] leading-relaxed mb-2">{cut.desc}</p>
                        <div className="flex flex-wrap gap-1">
                          {cut.tags.map((tag, i) => (
                            <span key={i} className="text-[9px] bg-[#F3F4F6] text-[#6B7280] px-1.5 py-0.5 rounded-full">{tag}</span>
                          ))}
                        </div>
                      </div>
                    </button>
                    <div className="px-2.5 pb-2">
                      <button onClick={() => setExpandedId(isExpanded ? null : cut.id)}
                        className="flex items-center gap-1 text-[9px] text-[#9CA3AF] hover:text-[#1B4332] transition-colors">
                        <Info size={10} />{isExpanded ? "접기" : "상세 설명"}
                      </button>
                      {isExpanded && (
                        <div className="mt-2 bg-white/70 rounded-xl p-2.5 border border-[#E8EDE8]">
                          <p className="text-[10px] text-[#374151] leading-relaxed">{cut.detail}</p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── STEP: 가위컷 스타일 ── */}
        {step === "scissor" && (
          <div>
            <div className="mb-5">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <span className="text-xs bg-[#D1FAE5] text-[#065F46] px-2 py-0.5 rounded-full font-bold">{selectedBase?.label}</span>
                <span className="text-xs">+</span>
                <span className="text-xs bg-[#F5F3FF] text-[#5B21B6] px-2 py-0.5 rounded-full font-bold">가위 컷</span>
              </div>
              <h2 className="text-xl font-bold text-[#1B4332] mb-1" style={{ fontFamily: "'Noto Serif KR', serif" }}>
                가위컷 스타일을 선택해주세요
              </h2>
              <p className="text-sm text-[#9CA3AF]">가위로만 만드는 섬세한 스타일입니다</p>
            </div>

            <div className="space-y-3">
              {SCISSOR_STYLES.map((style) => {
                const isSelected = selectedScissor?.id === style.id;
                const isExpanded = expandedId === style.id;
                return (
                  <div key={style.id} className={`rounded-2xl border-2 overflow-hidden transition-all duration-200 ${
                    isSelected ? "bg-[#FDF4FF] border-[#E879F9] shadow-md" : "bg-white border-[#E8EDE8]"
                  }`}>
                    <button className="w-full flex items-center gap-3 p-3 text-left" onClick={() => setSelectedScissor(style)}>
                      <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 bg-[#F3F4F6]">
                        <img src={style.img} alt={style.label} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-[#1B4332] mb-1">{style.label}</p>
                        <p className="text-xs text-[#6B7280] mb-2">{style.desc}</p>
                        <div className="flex flex-wrap gap-1">
                          {style.tags.map((tag, i) => (
                            <span key={i} className="text-[9px] bg-[#F5F3FF] text-[#5B21B6] px-1.5 py-0.5 rounded-full font-medium">{tag}</span>
                          ))}
                        </div>
                      </div>
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                        isSelected ? "bg-[#7C3AED] border-[#7C3AED]" : "border-[#D1D5DB]"
                      }`}>
                        {isSelected && <Check size={13} className="text-white" />}
                      </div>
                    </button>
                    <div className="px-3 pb-2">
                      <button onClick={() => setExpandedId(isExpanded ? null : style.id)}
                        className="flex items-center gap-1 text-[10px] text-[#9CA3AF] hover:text-[#1B4332] transition-colors">
                        <Info size={11} />{isExpanded ? "접기" : "자세히 보기"}
                      </button>
                      {isExpanded && (
                        <div className="mt-2 bg-white/70 rounded-xl p-3 border border-[#E8EDE8]">
                          <p className="text-xs text-[#374151] leading-relaxed">{style.detail}</p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── STEP: 최종 확인 ── */}
        {step === "summary" && (
          <div>
            <div className="mb-5">
              <h2 className="text-xl font-bold text-[#1B4332] mb-1" style={{ fontFamily: "'Noto Serif KR', serif" }}>
                선택 내용 확인
              </h2>
              <p className="text-sm text-[#9CA3AF]">선택하신 미용 스타일을 확인해주세요</p>
            </div>

            <div className="bg-white rounded-2xl border-2 border-[#D1FAE5] shadow-sm overflow-hidden mb-4">
              <div className="px-4 py-3 bg-[#F0FDF4] border-b border-[#D1FAE5] flex items-center gap-2">
                <span>✅</span>
                <h3 className="text-xs font-bold text-[#065F46] uppercase tracking-wider">선택 완료</h3>
              </div>

              {selectedBase && (
                <div className="p-4 border-b border-[#F3F4F6]">
                  <p className="text-[10px] text-[#9CA3AF] mb-2 font-medium uppercase tracking-wider">기본 서비스</p>
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0 bg-[#F3F4F6]">
                      <img src={selectedBase.img} alt={selectedBase.label} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#1B4332]">{selectedBase.emoji} {selectedBase.label}</p>
                      <p className="text-xs text-[#6B7280]">{selectedBase.desc}</p>
                      <div className="flex gap-1.5 mt-1">
                        <span className="text-[9px] bg-[#F0FDF4] text-[#059669] px-1.5 py-0.5 rounded-full font-medium">⏱ {selectedBase.time}</span>
                        <span className="text-[9px] bg-[#FEF9C3] text-[#92400E] px-1.5 py-0.5 rounded-full font-medium">💰 {selectedBase.price}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {selectedCut && (
                <div className="p-4 border-b border-[#F3F4F6]">
                  <p className="text-[10px] text-[#9CA3AF] mb-2 font-medium uppercase tracking-wider">컷 스타일</p>
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0 bg-[#F3F4F6]">
                      <img src={selectedCut.img} alt={selectedCut.label} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#1B4332]">{selectedCut.label}</p>
                      <p className="text-xs text-[#6B7280]">{selectedCut.desc}</p>
                    </div>
                  </div>
                </div>
              )}

              {selectedScissor && (
                <div className="p-4 border-b border-[#F3F4F6]">
                  <p className="text-[10px] text-[#9CA3AF] mb-2 font-medium uppercase tracking-wider">가위컷 스타일</p>
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0 bg-[#F3F4F6]">
                      <img src={selectedScissor.img} alt={selectedScissor.label} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#1B4332]">{selectedScissor.label}</p>
                      <p className="text-xs text-[#6B7280]">{selectedScissor.desc}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="p-4">
                <p className="text-[10px] text-[#9CA3AF] mb-1 font-medium">최종 선택</p>
                <p className="text-base font-bold text-[#1B4332]">🐾 {getFinalLabel()}</p>
              </div>
            </div>

            <div className="bg-[#FFFBEB] rounded-xl border border-[#FDE68A] p-3 mb-4">
              <p className="text-xs text-[#92400E] leading-relaxed">
                💡 <strong>참고:</strong> 실제 미용 시 담당 선생님이 반려견 상태를 확인 후 최적의 방법으로 진행합니다. 털 상태에 따라 일부 조정이 있을 수 있습니다.
              </p>
            </div>

            <Button
              className="w-full bg-[#1B4332] text-white font-bold text-sm rounded-xl shadow-lg mb-3"
              style={{ height: "52px" }}
              onClick={() => {
                // 선택한 스타일을 localStorage에 저장해 CheckinPage에서 자동 반영
                localStorage.setItem("grooming_style_selection", JSON.stringify({
                  baseService: selectedBase?.label,
                  cutType: selectedCut?.label,
                  scissorStyle: selectedScissor?.label,
                  finalLabel: getFinalLabel(),
                }));
                navigate("/checkin");
              }}
            >
              이 스타일로 접수하기 <ArrowRight size={16} className="ml-1" />
            </Button>
            <Button
              variant="outline"
              className="w-full h-11 text-sm border-[#E8EDE8] text-[#6B7280] hover:border-[#1B4332] hover:text-[#1B4332] bg-transparent rounded-xl"
              onClick={() => setStep("base")}
            >
              처음부터 다시 선택
            </Button>
          </div>
        )}
      </div>

      {/* Bottom CTA */}
      {step !== "summary" && (
        <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-[#E8EDE8] px-4 py-4 shadow-lg">
          <div className="max-w-lg mx-auto">
            {step === "base" && (
              <Button
                className="w-full bg-[#1B4332] text-white font-bold text-sm rounded-xl disabled:opacity-40 shadow-lg"
                style={{ height: "52px" }}
                disabled={!selectedBase}
                onClick={handleBaseNext}
              >
                {selectedBase
                  ? selectedBase.hasCut ? "컷 스타일 선택하기 →" : "이 서비스로 진행하기 →"
                  : "서비스를 선택해주세요"}
              </Button>
            )}
            {step === "cut" && (
              <Button
                className="w-full bg-[#1B4332] text-white font-bold text-sm rounded-xl disabled:opacity-40 shadow-lg"
                style={{ height: "52px" }}
                disabled={!selectedCut}
                onClick={handleCutNext}
              >
                {selectedCut
                  ? selectedCut.hasScissorStyle ? "가위컷 스타일 선택하기 →" : "이 스타일로 선택 →"
                  : "컷 스타일을 선택해주세요"}
              </Button>
            )}
            {step === "scissor" && (
              <Button
                className="w-full bg-[#1B4332] text-white font-bold text-sm rounded-xl disabled:opacity-40 shadow-lg"
                style={{ height: "52px" }}
                disabled={!selectedScissor}
                onClick={() => setStep("summary")}
              >
                {selectedScissor ? "선택 완료 →" : "스타일을 선택해주세요"}
              </Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
