import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ShieldAlert, RefreshCw, ToggleLeft, ToggleRight, Crown } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function AdminPage() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();

  const { data: shops, isLoading, refetch } = trpc.admin.listShops.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  const toggleMutation = trpc.admin.toggleShop.useMutation({
    onSuccess: () => { toast.success("매장 상태가 변경되었습니다."); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  const planMutation = trpc.admin.updatePlan.useMutation({
    onSuccess: () => { toast.success("플랜이 변경되었습니다."); refetch(); },
    onError: (err) => toast.error(err.message),
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FAFAF7] flex items-center justify-center">
        <Loader2 className="animate-spin text-[#1B4332]" size={32} />
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen bg-[#FAFAF7] flex flex-col items-center justify-center gap-4">
        <ShieldAlert size={48} className="text-red-400" />
        <h1 className="text-xl font-bold text-[#1B4332]">접근 권한 없음</h1>
        <p className="text-sm text-[#6B7280]">슈퍼 어드민만 접근할 수 있습니다.</p>
        <Button onClick={() => navigate("/")} variant="outline" className="border-[#1B4332] text-[#1B4332] bg-transparent">
          홈으로 돌아가기
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAF7]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>
      {/* 헤더 */}
      <header className="bg-[#1B4332] text-white sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-5 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Crown size={18} />
            <span className="font-bold">그루밍노트 슈퍼 어드민</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-white/70 text-sm">{user.name}</span>
            <Button
              size="sm"
              variant="outline"
              onClick={() => refetch()}
              className="border-white/30 text-white hover:bg-white/10 bg-transparent h-8 px-3"
            >
              <RefreshCw size={14} />
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-5 py-8">
        {/* 통계 카드 */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "전체 매장", value: shops?.length ?? 0, color: "bg-[#1B4332]", textColor: "text-white" },
            { label: "활성 매장", value: shops?.filter(s => s.active).length ?? 0, color: "bg-green-50", textColor: "text-green-700" },
            { label: "비활성 매장", value: shops?.filter(s => !s.active).length ?? 0, color: "bg-red-50", textColor: "text-red-700" },
            { label: "프로 플랜", value: shops?.filter(s => s.plan === "pro").length ?? 0, color: "bg-amber-50", textColor: "text-amber-700" },
          ].map((stat, i) => (
            <div key={i} className={`${stat.color} rounded-2xl p-5 border border-[#E8EDE8]`}>
              <p className={`text-3xl font-bold ${stat.textColor}`}>{stat.value}</p>
              <p className={`text-sm mt-1 ${stat.textColor} opacity-70`}>{stat.label}</p>
            </div>
          ))}
        </div>

        {/* 매장 목록 */}
        <div className="bg-white rounded-2xl border border-[#E8EDE8] overflow-hidden shadow-sm">
          <div className="px-6 py-4 border-b border-[#E8EDE8] flex items-center justify-between">
            <h2 className="font-bold text-[#1B4332]">전체 매장 목록</h2>
            <span className="text-sm text-[#9CA3AF]">{shops?.length ?? 0}개 매장</span>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 className="animate-spin text-[#1B4332]" size={24} />
            </div>
          ) : !shops || shops.length === 0 ? (
            <div className="text-center py-16 text-[#9CA3AF]">
              <p className="text-sm">등록된 매장이 없습니다.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-[#F9FAF9] border-b border-[#E8EDE8]">
                    <th className="text-left px-6 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">매장명</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">슬러그</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">이메일</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">플랜</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">상태</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">가입일</th>
                    <th className="text-right px-6 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider">관리</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F3F4F6]">
                  {shops.map((shop) => (
                    <tr key={shop.id} className="hover:bg-[#FAFAF7] transition-colors">
                      <td className="px-6 py-4">
                        <div>
                          <p className="font-semibold text-[#1B4332]">{shop.name}</p>
                          <p className="text-xs text-[#9CA3AF]">{shop.phone}</p>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="font-mono text-xs bg-[#F0FDF4] text-[#1B4332] px-2 py-1 rounded">
                          {shop.slug}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-[#6B7280] text-xs">{shop.ownerEmail}</td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <Badge
                            className={shop.plan === "pro"
                              ? "bg-amber-100 text-amber-700 border-amber-200 text-xs"
                              : "bg-gray-100 text-gray-600 border-gray-200 text-xs"
                            }
                          >
                            {shop.plan === "pro" ? "프로" : "무료"}
                          </Badge>
                          <button
                            onClick={() => planMutation.mutate({
                              shopId: shop.id,
                              plan: shop.plan === "pro" ? "free" : "pro",
                            })}
                            className="text-xs text-[#9CA3AF] hover:text-[#1B4332] transition-colors"
                            title="플랜 전환"
                          >
                            전환
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <Badge
                          className={shop.active
                            ? "bg-green-100 text-green-700 border-green-200 text-xs"
                            : "bg-red-100 text-red-600 border-red-200 text-xs"
                          }
                        >
                          {shop.active ? "활성" : "비활성"}
                        </Badge>
                      </td>
                      <td className="px-4 py-4 text-xs text-[#9CA3AF]">
                        {new Date(shop.createdAt).toLocaleDateString("ko-KR")}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button
                          onClick={() => toggleMutation.mutate({ shopId: shop.id, active: !shop.active })}
                          disabled={toggleMutation.isPending}
                          className="flex items-center gap-1 ml-auto text-xs font-medium transition-colors"
                          style={{ color: shop.active ? "#DC2626" : "#059669" }}
                        >
                          {shop.active
                            ? <><ToggleRight size={14} /> 비활성화</>
                            : <><ToggleLeft size={14} /> 활성화</>
                          }
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
