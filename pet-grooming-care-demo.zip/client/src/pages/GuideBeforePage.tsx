/**
 * Design: Modern Clinic + Pet Care Brand
 * GuideBeforePage v3: 예약 전 안내 화면 (보호자용) - 상품성 강화
 * 필수/중요 항목 강조 + 시각적 위계 강화 + 브랜드 히어로 + 강력한 CTA
 */
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ArrowRight, Phone, AlertTriangle, CheckCircle2 } from "lucide-react";
import { SHOP, GUIDE_BEFORE, TIME_TABLE } from "@/lib/shop-config";

// shop-config의 GUIDE_BEFORE를 UI용으로 변환
const checkItems = GUIDE_BEFORE.map((item) => ({
  ...item,
  tagColor:
    item.tag === "필수" ? "bg-[#FEE2E2] text-[#991B1B]" :
    item.tag === "중요" ? "bg-[#FEF9C3] text-[#92400E]" :
    item.tag === "권장" ? "bg-[#D1FAE5] text-[#065F46]" :
    "bg-[#EDE9FE] text-[#5B21B6]",
  borderColor:
    item.tag === "필수" ? "border-l-[#DC2626]" :
    item.tag === "중요" ? "border-l-[#D97706]" :
    item.tag === "권장" ? "border-l-[#059669]" :
    "border-l-[#7C3AED]",
  bgColor: "",
  priority: item.tag === "필수" ? "high" : item.tag === "중요" ? "medium" : "low",
}));

// shop-config의 TIME_TABLE 사용
const timeTable = TIME_TABLE;


export default function GuideBeforePage() {
  const [, navigate] = useLocation();

  const highPriority = checkItems.filter((i) => i.priority === "high");
  const mediumPriority = checkItems.filter((i) => i.priority === "medium");
  const lowPriority = checkItems.filter((i) => i.priority === "low");

  return (
    <div className="min-h-screen bg-[#FAFAF7]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#E8EDE8]">
        <div className="max-w-lg mx-auto px-4 flex items-center h-14">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-1 text-[#1B4332] text-sm font-medium"
          >
            <ChevronLeft size={18} />
            홈
          </button>
          <div className="mx-auto text-center">
            <span className="font-bold text-[#1B4332] text-sm block leading-tight">{SHOP.logoEmoji} {SHOP.name}</span>
            <span className="text-[10px] text-[#9CA3AF]">방문 전 안내</span>
          </div>
          <div className="w-16" />
        </div>
      </header>

      {/* Brand Hero */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[#1B4332] to-[#2D6A4F] px-5 pt-8 pb-16">
        <div className="absolute top-0 right-0 w-48 h-48 rounded-full bg-white/5 -translate-y-1/3 translate-x-1/3" />
        <div className="absolute bottom-0 left-0 w-32 h-32 rounded-full bg-[#6EE7B7]/10 translate-y-1/2 -translate-x-1/4" />
        <div className="relative max-w-lg mx-auto">
          <div className="flex items-center gap-2 mb-5">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-xl border border-white/30">🐾</div>
            <div>
              <p className="text-white font-bold text-base leading-tight">{SHOP.name}</p>
              <p className="text-white/60 text-xs">{SHOP.subtitle}</p>
            </div>
          </div>
          <h1
            className="text-2xl font-bold text-white mb-2 leading-snug"
            style={{ fontFamily: "'Noto Serif KR', serif" }}
          >
            방문 전 꼭 확인해주세요 🐾
          </h1>
          <p className="text-white/70 text-sm leading-relaxed mb-5">
            아래 안내를 미리 확인하시면 더 편안하고 안전한 미용이 가능합니다.
          </p>
          {/* Quick stats */}
          <div className="flex gap-3">
            <div className="bg-white/15 border border-white/20 rounded-xl px-3 py-2 text-center flex-1">
              <p className="text-white font-bold text-lg leading-none">6</p>
              <p className="text-white/60 text-[10px] mt-0.5">확인 항목</p>
            </div>
            <div className="bg-white/15 border border-white/20 rounded-xl px-3 py-2 text-center flex-1">
              <p className="text-white font-bold text-lg leading-none">2</p>
              <p className="text-white/60 text-[10px] mt-0.5">필수 항목</p>
            </div>
            <div className="bg-white/15 border border-white/20 rounded-xl px-3 py-2 text-center flex-1">
              <p className="text-white font-bold text-lg leading-none">3분</p>
              <p className="text-white/60 text-[10px] mt-0.5">읽기 시간</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 -mt-4 pb-10 space-y-4">

        {/* 필수 항목 — 강조 카드 */}
        <div className="bg-[#FFF5F5] rounded-2xl border-2 border-[#FCA5A5] shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-[#FEE2E2] bg-[#FEE2E2] flex items-center gap-2">
            <AlertTriangle size={13} className="text-[#DC2626]" />
            <h2 className="text-xs font-bold text-[#991B1B] uppercase tracking-wider">필수 확인 사항</h2>
            <span className="ml-auto text-[10px] bg-[#DC2626] text-white px-2 py-0.5 rounded-full font-bold">반드시 읽어주세요</span>
          </div>
          {highPriority.map((item, i) => (
            <div
              key={i}
              className={`px-4 py-4 flex items-start gap-3 border-l-4 ${item.borderColor} ${i < highPriority.length - 1 ? "border-b border-[#FEE2E2]" : ""}`}
            >
              <div className="w-9 h-9 rounded-xl bg-[#FEE2E2] flex items-center justify-center text-lg flex-shrink-0 mt-0.5">
                {item.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="text-sm font-bold text-[#1B4332]">{item.title}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex-shrink-0 ${item.tagColor}`}>
                    {item.tag}
                  </span>
                </div>
                <p className="text-xs text-[#6B7280] leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* 중요 항목 */}
        <div className="bg-[#FFFBEB] rounded-2xl border-2 border-[#FDE68A] shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-[#FDE68A] bg-[#FEF9C3] flex items-center gap-2">
            <span className="text-xs">⚠️</span>
            <h2 className="text-xs font-bold text-[#92400E] uppercase tracking-wider">중요 안내</h2>
          </div>
          {mediumPriority.map((item, i) => (
            <div
              key={i}
              className={`px-4 py-4 flex items-start gap-3 border-l-4 ${item.borderColor} ${i < mediumPriority.length - 1 ? "border-b border-[#FEF9C3]" : ""}`}
            >
              <div className="w-9 h-9 rounded-xl bg-[#FEF9C3] flex items-center justify-center text-lg flex-shrink-0 mt-0.5">
                {item.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="text-sm font-semibold text-[#1B4332]">{item.title}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex-shrink-0 ${item.tagColor}`}>
                    {item.tag}
                  </span>
                </div>
                <p className="text-xs text-[#6B7280] leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* 권장/참고 항목 */}
        <div className="bg-white rounded-2xl border border-[#E8EDE8] shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-[#F3F4F6] bg-[#FAFAFA] flex items-center gap-2">
            <CheckCircle2 size={13} className="text-[#059669]" />
            <h2 className="text-xs font-bold text-[#6B7280] uppercase tracking-wider">권장 사항</h2>
          </div>
          {lowPriority.map((item, i) => (
            <div
              key={i}
              className={`px-4 py-4 flex items-start gap-3 border-l-4 ${item.borderColor} ${i < lowPriority.length - 1 ? "border-b border-[#F9FAFB]" : ""}`}
            >
              <div className="w-9 h-9 rounded-xl bg-[#F0FDF4] flex items-center justify-center text-lg flex-shrink-0 mt-0.5">
                {item.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="text-sm font-semibold text-[#1B4332]">{item.title}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${item.tagColor}`}>
                    {item.tag}
                  </span>
                </div>
                <p className="text-xs text-[#6B7280] leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Time Table */}
        <div className="bg-white rounded-2xl border border-[#E8EDE8] shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-[#F3F4F6] bg-[#FAFAFA] flex items-center gap-2">
            <span className="text-sm">⏱</span>
            <h2 className="text-xs font-bold text-[#6B7280] uppercase tracking-wider">예상 소요시간</h2>
          </div>
          {timeTable.map((row, i) => (
            <div
              key={i}
              className={`px-4 py-3.5 flex items-center justify-between ${i < timeTable.length - 1 ? "border-b border-[#F9FAFB]" : ""} ${i === timeTable.length - 1 ? "bg-[#FFFBEB]" : ""}`}
            >
              <div>
                <p className="text-sm font-semibold text-[#1B4332]">{row.type}</p>
                <p className="text-xs text-[#9CA3AF] mt-0.5">{row.examples}</p>
              </div>
              <span className={`text-xs font-bold px-3 py-1.5 rounded-full flex-shrink-0 ml-3 ${row.color}`}>
                {row.time}
              </span>
            </div>
          ))}
        </div>

        {/* Contact */}
        <div className="bg-[#1B4332] rounded-2xl p-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-white text-sm mb-1">문의사항이 있으신가요?</h3>
              <p className="text-white/60 text-xs leading-relaxed">
                미용 중에는 전화 응대가 어려울 수 있으니<br />
                방문 전 미리 연락 주시면 감사합니다.
              </p>
            </div>
            <a
              href={`tel:${SHOP.phone}`}
              className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-2 rounded-xl transition-colors flex-shrink-0 ml-3"
            >
              <Phone size={13} />
              전화하기
            </a>
          </div>
          <div className="mt-3 pt-3 border-t border-white/10">
            <p className="text-white/80 text-sm font-bold">📱 {SHOP.phone}</p>
          </div>
        </div>

        {/* CTA */}
        <Button
          className="w-full bg-[#1B4332] hover:bg-[#145229] text-white h-13 text-sm font-bold rounded-xl shadow-lg"
          style={{ height: "52px" }}
          onClick={() => navigate("/status/demo-001")}
        >
          미용 진행 상황 확인하기 <ArrowRight size={16} className="ml-1" />
        </Button>
      </div>
    </div>
  );
}
