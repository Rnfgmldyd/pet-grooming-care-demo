/**
 * 그루밍노트 (GroomingNote) - SaaS 랜딩 페이지
 * 애견미용실 전용 보호자 안심 안내 SaaS 서비스
 * Design: Deep Forest Green #1B4332, Cream #FAFAF7, Noto Serif KR + Noto Sans KR
 */
import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  ArrowRight, CheckCircle2, Scissors, Smartphone, Monitor,
  MessageCircleOff, Shield, Clock, Zap, Star, ChevronDown,
  Phone, Users, TrendingUp, Bell
} from "lucide-react";

/* ── 애니메이션 카운터 ── */
function CountUp({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          let start = 0;
          const step = Math.ceil(target / 40);
          const timer = setInterval(() => {
            start += step;
            if (start >= target) { setCount(target); clearInterval(timer); }
            else setCount(start);
          }, 30);
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);

  return <span ref={ref}>{count}{suffix}</span>;
}

/* ── 폰 목업 ── */
function PhoneMockup({ step = 2 }: { step?: number }) {
  const stages = ["접수완료", "미용준비중", "목욕중", "드라이중", "커트중", "마무리중", "완료"];
  const icons = ["📋", "🐾", "🛁", "💨", "✂️", "✨", "🎉"];
  const colors = ["#0369A1", "#7C3AED", "#1D4ED8", "#D97706", "#059669", "#DB2777", "#1B4332"];
  const pct = Math.round(((step + 1) / 7) * 100);

  return (
    <div className="relative w-[190px] mx-auto select-none">
      <div className="bg-[#1A1A2E] rounded-[30px] p-2 shadow-2xl border border-white/10">
        <div className="bg-[#F4F7F4] rounded-[22px] overflow-hidden" style={{ height: "370px" }}>
          <div className="bg-[#1B4332] px-3 py-2 flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-[#6EE7B7] animate-pulse" />
              <span className="text-white text-[8px] font-bold">미용 진행 중</span>
            </div>
            <span className="text-white/50 text-[7px]">그루밍노트</span>
          </div>
          <div className="bg-gradient-to-br from-[#1B4332] to-[#2D6A4F] px-3 pt-3 pb-5">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-lg border border-white/30">🐶</div>
              <div>
                <p className="text-white font-bold text-xs">초코</p>
                <p className="text-white/60 text-[8px]">말티즈 · 3살</p>
              </div>
            </div>
            <div className="bg-white/15 rounded-xl p-2 border border-white/20">
              <p className="text-white/50 text-[7px] mb-0.5 uppercase tracking-wider">현재 단계</p>
              <div className="flex items-center gap-1.5">
                <span className="text-lg">{icons[step]}</span>
                <p className="text-white font-bold text-xs">{stages[step]}</p>
              </div>
            </div>
          </div>
          <div className="mx-2 -mt-3 bg-white rounded-xl p-2.5 shadow-md border border-gray-100">
            <div className="flex justify-between items-center mb-1.5">
              <span className="text-[8px] font-bold text-[#1B4332]">미용 진행률</span>
              <span className="text-[10px] font-bold text-[#1B4332]">{pct}%</span>
            </div>
            <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden mb-2">
              <div
                className="h-full rounded-full transition-all duration-1000"
                style={{ width: `${pct}%`, background: colors[step] }}
              />
            </div>
            <div className="flex justify-between">
              {stages.map((_, idx) => (
                <div
                  key={idx}
                  className="w-4 h-4 rounded-full flex items-center justify-center text-[7px] transition-all duration-300"
                  style={{
                    background: idx <= step ? colors[Math.min(idx, step)] : "#F3F4F6",
                    color: idx <= step ? "white" : "#D1D5DB",
                    transform: idx === step ? "scale(1.3)" : "scale(1)",
                  }}
                >
                  {idx < step ? "✓" : icons[idx]}
                </div>
              ))}
            </div>
          </div>
          <div className="mx-2 mt-2 grid grid-cols-2 gap-1.5">
            <div className="bg-white rounded-lg p-2 border border-gray-100 flex items-center gap-1.5">
              <div className="w-4 h-4 rounded bg-green-100 flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              </div>
              <div>
                <p className="text-[6px] text-gray-400">자동 새로고침</p>
                <p className="text-[8px] font-bold text-[#1B4332]">실시간</p>
              </div>
            </div>
            <div className="bg-white rounded-lg p-2 border border-gray-100 flex items-center gap-1.5">
              <div className="w-4 h-4 rounded bg-green-100 flex items-center justify-center text-[8px]">📞</div>
              <div>
                <p className="text-[6px] text-gray-400">긴급 문의</p>
                <p className="text-[8px] font-bold text-[#1B4332]">전화하기</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute top-3.5 left-1/2 -translate-x-1/2 w-10 h-1.5 bg-[#0A0A1A] rounded-full" />
    </div>
  );
}

const features = [
  {
    icon: <MessageCircleOff size={20} className="text-[#1B4332]" />,
    title: "반복 문의 전화 차단",
    desc: "보호자가 링크 하나로 모든 진행 상황을 실시간 확인합니다. 미용 중 전화 87% 감소.",
  },
  {
    icon: <Shield size={20} className="text-[#1B4332]" />,
    title: "클레임 예방 기록",
    desc: "요청사항이 접수 시점에 기록되어 분쟁 발생 시 명확한 근거 자료가 됩니다.",
  },
  {
    icon: <Zap size={20} className="text-[#1B4332]" />,
    title: "버튼 하나로 전달",
    desc: "직원이 단계 버튼 하나만 누르면 보호자 화면이 즉시 업데이트됩니다.",
  },
  {
    icon: <Clock size={20} className="text-[#1B4332]" />,
    title: "픽업 타이밍 최적화",
    desc: "완료 즉시 픽업 안내가 자동 전달되어 대기 혼잡을 줄입니다.",
  },
  {
    icon: <Users size={20} className="text-[#1B4332]" />,
    title: "다두 동시 관리",
    desc: "여러 반려견을 동시에 관리하고 각각의 진행 상황을 개별 추적합니다.",
  },
  {
    icon: <TrendingUp size={20} className="text-[#1B4332]" />,
    title: "매장 신뢰도 향상",
    desc: "전문적인 안내 시스템이 프리미엄 매장 이미지를 만들어 재방문율을 높입니다.",
  },
];

const steps = [
  { num: "01", emoji: "📝", title: "매장 가입", desc: "매장명과 서비스 주소를 입력하고 무료로 시작합니다" },
  { num: "02", emoji: "🔐", title: "PIN 설정", desc: "4자리 직원 PIN을 설정하면 즉시 사용 가능합니다" },
  { num: "03", emoji: "🐾", title: "접수 시작", desc: "QR 코드나 직원 화면으로 반려견을 접수합니다" },
  { num: "04", emoji: "✂️", title: "실시간 안내", desc: "단계 버튼 하나로 보호자에게 자동 전달됩니다" },
];

const faqs = [
  { q: "별도 앱 설치가 필요한가요?", a: "앱 설치 없이 웹 링크로 바로 사용합니다. 직원은 즐겨찾기 등록, 보호자는 링크 클릭만으로 접속합니다." },
  { q: "무료 플랜에서 사용 가능한 기능은?", a: "접수 관리, 실시간 진행 상황 공유, 직원 PIN 로그인, 전체 이력 조회 등 핵심 기능이 모두 무료로 제공됩니다." },
  { q: "카카오 알림톡 자동 발송이 되나요?", a: "카카오 알림톡 연동은 프로 플랜에서 지원 예정입니다. 현재는 링크 공유 방식으로 운영됩니다." },
  { q: "여러 직원이 함께 사용할 수 있나요?", a: "네, 매장 PIN을 공유하면 여러 직원이 동일한 화면에서 접수 및 상태 관리를 할 수 있습니다." },
  { q: "데이터는 안전하게 보관되나요?", a: "모든 데이터는 암호화되어 안전하게 저장됩니다. 접수 이력은 영구 보관되며 언제든지 조회 가능합니다." },
];

export default function Home() {
  const [, navigate] = useLocation();
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [activeStep, setActiveStep] = useState(2);

  useEffect(() => {
    const t = setInterval(() => setActiveStep(s => (s + 1) % 7), 2200);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="min-h-screen bg-[#FAFAF7]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>

      {/* ── 네비게이션 ── */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#E8EDE8]">
        <div className="max-w-5xl mx-auto px-5 flex items-center justify-between h-14">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#1B4332] flex items-center justify-center">
              <Scissors size={16} className="text-white" />
            </div>
            <div>
              <span className="font-bold text-[#1B4332] text-sm block leading-tight" style={{ fontFamily: "'Noto Serif KR', serif" }}>그루밍노트</span>
              <span className="text-[10px] text-[#9CA3AF] leading-tight block">애견미용실 전용 SaaS</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-[#E8EDE8] text-[#1B4332] text-xs h-8 px-3 bg-transparent hidden sm:flex"
              onClick={() => navigate("/staff-login")}
            >
              직원 로그인
            </Button>
            <Button
              size="sm"
              className="bg-[#1B4332] hover:bg-[#145229] text-white text-xs h-8 px-4"
              onClick={() => navigate("/register")}
            >
              무료 시작 →
            </Button>
          </div>
        </div>
      </nav>

      {/* ── 히어로 ── */}
      <section className="relative overflow-hidden bg-[#1B4332]">
        <div className="absolute inset-0">
          <div className="absolute inset-0 opacity-10" style={{
            backgroundImage: `url("https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=1400&auto=format&fit=crop&q=60")`,
            backgroundSize: "cover",
            backgroundPosition: "center 30%",
          }} />
          <div className="absolute inset-0 bg-gradient-to-b from-[#1B4332]/80 via-[#1B4332]/60 to-[#1B4332]" />
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white/5 -translate-y-1/2 translate-x-1/3" />
          <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full bg-[#6EE7B7]/10 translate-y-1/2 -translate-x-1/4" />
        </div>

        <div className="relative max-w-5xl mx-auto px-5 pt-14 pb-20 md:pt-20 md:pb-28">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            {/* 카피 */}
            <div>
              <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm border border-white/20 rounded-full px-4 py-1.5 mb-6">
                <span className="w-2 h-2 rounded-full bg-[#34D399] animate-pulse" />
                <span className="text-white text-xs font-medium">애견미용실 전용 · 무료로 시작</span>
              </div>

              <h1
                className="text-4xl md:text-5xl font-bold text-white leading-[1.15] mb-5"
                style={{ fontFamily: "'Noto Serif KR', serif" }}
              >
                미용 중 전화,<br />
                <span className="text-[#6EE7B7]">이제 받지 마세요.</span>
              </h1>
              <p className="text-white/75 text-base leading-relaxed mb-7 max-w-xl">
                그루밍노트는 애견미용실 전용 SaaS입니다.<br />
                보호자가 링크 하나로 모든 과정을 확인하고,<br />
                직원은 버튼 하나만 누르면 됩니다.
              </p>

              <div className="flex flex-wrap gap-3 mb-10">
                <Button
                  className="bg-white text-[#1B4332] hover:bg-[#F0FDF4] font-bold px-7 text-sm rounded-xl shadow-lg"
                  style={{ height: "52px" }}
                  onClick={() => navigate("/register")}
                >
                  무료로 시작하기 <ArrowRight size={16} className="ml-1.5" />
                </Button>
                <Button
                  variant="outline"
                  className="border-white/40 text-white hover:bg-white/10 bg-transparent text-sm rounded-xl"
                  style={{ height: "52px", padding: "0 28px" }}
                  onClick={() => navigate("/status/demo-001")}
                >
                  데모 체험하기
                </Button>
              </div>

              {/* 통계 */}
              <div className="flex flex-wrap gap-6">
                {[
                  { value: 87, suffix: "%", label: "반복 문의 감소", noCount: false },
                  { value: 0, suffix: "건", label: "요청사항 누락", noCount: false },
                  { value: "4.9", suffix: "★", label: "보호자 만족도", noCount: true },
                ].map((s, i) => (
                  <div key={i} className="flex items-center gap-4">
                    <div>
                      <p className="text-[#6EE7B7] font-bold text-2xl leading-none">
                        {s.noCount ? `${s.value}${s.suffix}` : <CountUp target={s.value as number} suffix={s.suffix} />}
                      </p>
                      <p className="text-white/55 text-xs mt-1">{s.label}</p>
                    </div>
                    {i < 2 && <div className="w-px h-9 bg-white/15" />}
                  </div>
                ))}
              </div>
            </div>

            {/* 폰 목업 */}
            <div className="hidden md:flex justify-center items-center">
              <div className="relative">
                <div style={{ animation: "float 3s ease-in-out infinite" }}>
                  <PhoneMockup step={activeStep} />
                </div>
                <div className="absolute -left-14 top-16 bg-white rounded-2xl shadow-xl px-3 py-2 border border-[#E8EDE8]" style={{ animation: "float 3s ease-in-out infinite", animationDelay: "0.5s" }}>
                  <div className="flex items-center gap-2">
                    <span className="text-lg">✂️</span>
                    <div>
                      <p className="text-[9px] text-gray-400">현재 단계</p>
                      <p className="text-xs font-bold text-[#1B4332]">커트중</p>
                    </div>
                  </div>
                </div>
                <div className="absolute -right-12 bottom-20 bg-white rounded-2xl shadow-xl px-3 py-2 border border-[#E8EDE8]" style={{ animation: "float 3s ease-in-out infinite", animationDelay: "1s" }}>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                    </div>
                    <p className="text-xs font-bold text-[#1B4332]">실시간 업데이트</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── 기능 ── */}
      <section className="bg-[#FAFAF7] py-16">
        <div className="max-w-5xl mx-auto px-5">
          <div className="text-center mb-10">
            <p className="text-xs font-bold text-[#059669] uppercase tracking-widest mb-3">핵심 기능</p>
            <h2 className="text-2xl md:text-3xl font-bold text-[#1B4332]" style={{ fontFamily: "'Noto Serif KR', serif" }}>
              필요한 기능만, 딱 맞게
            </h2>
            <p className="text-sm text-[#6B7280] mt-2">복잡한 설정 없이 바로 사용 가능합니다</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {features.map((f, i) => (
              <div key={i} className="bg-white rounded-2xl p-5 border border-[#E8EDE8] shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200">
                <div className="w-10 h-10 rounded-xl bg-[#D1FAE5] flex items-center justify-center mb-4">
                  {f.icon}
                </div>
                <h3 className="font-bold text-[#1B4332] text-sm mb-2">{f.title}</h3>
                <p className="text-xs text-[#6B7280] leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 화면 미리보기 ── */}
      <section className="bg-[#1B4332] py-16 overflow-hidden">
        <div className="max-w-5xl mx-auto px-5">
          <div className="text-center mb-12">
            <p className="text-xs font-bold text-[#6EE7B7] uppercase tracking-widest mb-3">실제 화면</p>
            <h2 className="text-2xl md:text-3xl font-bold text-white" style={{ fontFamily: "'Noto Serif KR', serif" }}>
              보호자와 직원, 각자의 화면
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-10 items-start">
            {/* 보호자 화면 */}
            <div>
              <div className="flex items-center gap-2 mb-5">
                <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center">
                  <Smartphone size={14} className="text-white" />
                </div>
                <div>
                  <p className="text-white font-bold text-sm">보호자 화면</p>
                  <p className="text-white/50 text-xs">링크 하나로 실시간 확인</p>
                </div>
              </div>
              <PhoneMockup step={activeStep} />
              <div className="mt-4 grid grid-cols-3 gap-2">
                {[
                  { emoji: "📋", label: "예약 전 안내", path: "/guide" },
                  { emoji: "🛁", label: "진행 상황", path: "/status/demo-001" },
                  { emoji: "🎉", label: "완료 안내", path: "/complete/demo-003" },
                ].map(btn => (
                  <button
                    key={btn.path}
                    onClick={() => navigate(btn.path)}
                    className="bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl py-2 px-2 text-center transition-all"
                  >
                    <span className="text-lg block mb-0.5">{btn.emoji}</span>
                    <span className="text-white text-[9px] font-medium">{btn.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 직원 화면 */}
            <div>
              <div className="flex items-center gap-2 mb-5">
                <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center">
                  <Monitor size={14} className="text-white" />
                </div>
                <div>
                  <p className="text-white font-bold text-sm">직원 관리 화면</p>
                  <p className="text-white/50 text-xs">버튼 하나로 상태 변경</p>
                </div>
              </div>
              {/* 직원 화면 목업 */}
              <div className="bg-white rounded-2xl overflow-hidden shadow-xl border-2 border-white/20 max-w-[300px] mx-auto">
                <div className="bg-[#1B4332] px-4 py-3 flex items-center justify-between">
                  <div>
                    <p className="text-white font-bold text-sm">🐾 직원 관리</p>
                    <p className="text-white/50 text-[10px]">그루밍노트</p>
                  </div>
                  <div className="bg-white/20 text-white text-xs font-bold px-2.5 py-1 rounded-lg">+ 접수</div>
                </div>
                <div className="grid grid-cols-3 gap-2 p-3 bg-[#F4F7F4]">
                  {[
                    { label: "진행 중", value: "2", color: "#DBEAFE", icon: "✂️" },
                    { label: "완료", value: "1", color: "#D1FAE5", icon: "✅" },
                    { label: "특이사항", value: "0", color: "#FEE2E2", icon: "⚠️" },
                  ].map((s, i) => (
                    <div key={i} className="bg-white rounded-xl p-2 text-center border border-gray-100">
                      <div className="w-6 h-6 rounded-lg flex items-center justify-center mx-auto mb-1 text-xs" style={{ background: s.color }}>{s.icon}</div>
                      <p className="text-base font-bold text-[#1B4332]">{s.value}</p>
                      <p className="text-[8px] text-gray-400">{s.label}</p>
                    </div>
                  ))}
                </div>
                <div className="p-3">
                  <div className="bg-white rounded-xl border-2 border-[#1B4332]/20 overflow-hidden shadow-sm">
                    <div className="h-1 bg-[#1D4ED8]" />
                    <div className="p-3 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-[#DBEAFE] flex items-center justify-center text-xl flex-shrink-0">🛁</div>
                      <div className="flex-1">
                        <div className="flex items-center gap-1.5 mb-0.5">
                          <span className="font-bold text-[#1B4332] text-sm">초코</span>
                          <span className="text-[9px] text-gray-400">말티즈</span>
                        </div>
                        <span className="text-[9px] font-bold bg-[#DBEAFE] text-[#1D4ED8] px-2 py-0.5 rounded-full">목욕중</span>
                      </div>
                    </div>
                    <div className="mx-3 mb-3 bg-gradient-to-r from-[#D97706] to-[#B45309] rounded-xl px-3 py-2.5 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">💨</span>
                        <div>
                          <p className="text-[7px] text-white/60 uppercase tracking-wider">다음 단계</p>
                          <p className="text-xs font-bold text-white">드라이중</p>
                        </div>
                      </div>
                      <span className="text-white text-xs">→</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2 max-w-[300px] mx-auto">
                {[
                  { emoji: "📋", label: "직원 화면 체험", path: "/staff" },
                  { emoji: "📝", label: "접수 폼 체험", path: "/checkin" },
                ].map(btn => (
                  <button
                    key={btn.path}
                    onClick={() => navigate(btn.path)}
                    className="bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl py-2.5 px-3 flex items-center justify-center gap-2 transition-all"
                  >
                    <span className="text-white text-sm">{btn.emoji}</span>
                    <span className="text-white text-xs font-medium">{btn.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── 사용 방법 ── */}
      <section className="bg-[#FAFAF7] py-16">
        <div className="max-w-5xl mx-auto px-5">
          <div className="text-center mb-10">
            <p className="text-xs font-bold text-[#059669] uppercase tracking-widest mb-3">시작 방법</p>
            <h2 className="text-2xl md:text-3xl font-bold text-[#1B4332]" style={{ fontFamily: "'Noto Serif KR', serif" }}>
              4단계로 바로 시작
            </h2>
            <p className="text-sm text-[#6B7280] mt-2">복잡한 설정 없이 5분 안에 시작 가능합니다</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {steps.map((step, i) => (
              <div key={i} className="relative text-center">
                {i < steps.length - 1 && (
                  <div className="hidden md:block absolute top-7 left-[calc(50%+32px)] right-[calc(-50%+32px)] h-px bg-[#D1FAE5]" />
                )}
                <div className="w-14 h-14 rounded-2xl bg-[#F0FDF4] border-2 border-[#D1FAE5] flex items-center justify-center mx-auto mb-4 text-2xl shadow-sm">
                  {step.emoji}
                </div>
                <span className="text-[#059669] text-xs font-bold block mb-1.5">{step.num}</span>
                <h4 className="text-[#1B4332] font-bold text-sm mb-1.5">{step.title}</h4>
                <p className="text-[#6B7280] text-xs leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 요금제 ── */}
      <section className="bg-[#F0FDF4] border-y border-[#A7F3D0] py-16">
        <div className="max-w-5xl mx-auto px-5">
          <div className="text-center mb-10">
            <p className="text-xs font-bold text-[#059669] uppercase tracking-widest mb-3">요금제</p>
            <h2 className="text-2xl md:text-3xl font-bold text-[#1B4332]" style={{ fontFamily: "'Noto Serif KR', serif" }}>
              지금은 모두 무료
            </h2>
            <p className="text-sm text-[#6B7280] mt-2">베타 기간 동안 모든 기능을 무료로 사용하세요</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-3xl mx-auto">
            {/* 무료 플랜 */}
            <div className="bg-white rounded-2xl p-7 border-2 border-[#E8EDE8] shadow-sm">
              <div className="mb-6">
                <h3 className="font-bold text-[#1B4332] text-xl mb-1">무료 플랜</h3>
                <p className="text-xs text-[#6B7280]">지금 바로 시작</p>
              </div>
              <div className="mb-6 pb-6 border-b border-[#F3F4F6]">
                <span className="text-5xl font-bold text-[#1B4332]">₩0</span>
                <span className="text-sm text-[#9CA3AF] ml-2">/월</span>
              </div>
              <ul className="space-y-3 mb-7">
                {[
                  "실시간 진행 상황 공유",
                  "직원 PIN 로그인",
                  "QR 접수 폼",
                  "전체 접수 이력",
                  "무제한 접수",
                  "모바일 최적화",
                ].map(f => (
                  <li key={f} className="flex items-center gap-2.5 text-sm text-[#4B5563]">
                    <CheckCircle2 size={15} className="text-[#059669] flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <Button
                className="w-full bg-[#1B4332] hover:bg-[#145229] text-white font-bold h-12 rounded-xl text-sm"
                onClick={() => navigate("/register")}
              >
                무료로 시작하기 →
              </Button>
            </div>

            {/* 프로 플랜 (예정) */}
            <div className="bg-[#1B4332] rounded-2xl p-7 border-2 border-[#1B4332] relative shadow-xl">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <span className="bg-[#D97706] text-white text-xs font-bold px-5 py-1.5 rounded-full shadow-md">출시 예정</span>
              </div>
              <div className="mb-6">
                <h3 className="font-bold text-white text-xl mb-1">프로 플랜</h3>
                <p className="text-xs text-white/55">추가 기능 출시 예정</p>
              </div>
              <div className="mb-6 pb-6 border-b border-white/15">
                <span className="text-3xl font-bold text-white/50">준비 중</span>
              </div>
              <ul className="space-y-3 mb-7">
                {[
                  "무료 플랜 전체 포함",
                  "카카오 알림톡 자동 발송",
                  "미용 완료 사진 첨부",
                  "다매장 통합 관리",
                  "매출 통계 대시보드",
                  "우선 고객 지원",
                ].map(f => (
                  <li key={f} className="flex items-center gap-2.5 text-sm text-white/60">
                    <CheckCircle2 size={15} className="text-white/30 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <Button disabled className="w-full bg-white/20 text-white/50 font-bold h-12 rounded-xl text-sm cursor-not-allowed">
                출시 예정
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="bg-[#FAFAF7] py-16">
        <div className="max-w-2xl mx-auto px-5">
          <div className="text-center mb-10">
            <p className="text-xs font-bold text-[#059669] uppercase tracking-widest mb-3">자주 묻는 질문</p>
            <h2 className="text-2xl font-bold text-[#1B4332]" style={{ fontFamily: "'Noto Serif KR', serif" }}>
              궁금하신 점이 있으신가요?
            </h2>
          </div>
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <div key={i} className="bg-white rounded-2xl border border-[#E8EDE8] overflow-hidden shadow-sm">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between px-5 py-4 text-left"
                >
                  <span className="text-sm font-semibold text-[#1B4332] pr-4">{faq.q}</span>
                  <ChevronDown
                    size={16}
                    className={`text-[#9CA3AF] flex-shrink-0 transition-transform duration-200 ${openFaq === i ? "rotate-180" : ""}`}
                  />
                </button>
                {openFaq === i && (
                  <div className="px-5 pb-4 border-t border-[#F3F4F6]">
                    <p className="text-sm text-[#6B7280] leading-relaxed pt-3">{faq.a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA 배너 ── */}
      <section className="bg-[#1B4332] py-16">
        <div className="max-w-2xl mx-auto px-5 text-center">
          <div className="w-14 h-14 rounded-2xl bg-white/15 flex items-center justify-center mx-auto mb-5">
            <Scissors size={24} className="text-white" />
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4" style={{ fontFamily: "'Noto Serif KR', serif" }}>
            지금 바로 시작하세요
          </h2>
          <p className="text-white/65 text-sm mb-8 leading-relaxed">
            5분 안에 매장을 등록하고 즉시 사용 가능합니다.<br />
            신용카드 없이, 무료로 시작하세요.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              className="bg-white text-[#1B4332] hover:bg-[#F0FDF4] font-bold px-8 text-sm rounded-xl shadow-lg"
              style={{ height: "52px" }}
              onClick={() => navigate("/register")}
            >
              무료 매장 등록하기 <ArrowRight size={16} className="ml-1.5" />
            </Button>
            <Button
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 bg-transparent rounded-xl px-8 text-sm font-semibold"
              style={{ height: "52px" }}
              onClick={() => navigate("/status/demo-001")}
            >
              데모 먼저 체험하기
            </Button>
          </div>
        </div>
      </section>

      {/* ── 푸터 ── */}
      <footer className="py-8 text-center border-t border-[#E8EDE8] bg-[#FAFAF7]">
        <div className="flex items-center justify-center gap-2 mb-2">
          <div className="w-6 h-6 rounded-lg bg-[#1B4332] flex items-center justify-center">
            <Scissors size={12} className="text-white" />
          </div>
          <span className="text-xs font-bold text-[#1B4332]" style={{ fontFamily: "'Noto Serif KR', serif" }}>그루밍노트</span>
        </div>
        <p className="text-xs text-[#9CA3AF]">© 2025 그루밍노트 · 애견미용실 전용 SaaS</p>
        <div className="flex items-center justify-center gap-4 mt-3">
          <button onClick={() => navigate("/register")} className="text-xs text-[#9CA3AF] hover:text-[#1B4332] transition-colors">매장 가입</button>
          <button onClick={() => navigate("/staff-login")} className="text-xs text-[#9CA3AF] hover:text-[#1B4332] transition-colors">직원 로그인</button>
          <button onClick={() => navigate("/status/demo-001")} className="text-xs text-[#9CA3AF] hover:text-[#1B4332] transition-colors">데모 체험</button>
        </div>
      </footer>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
      `}</style>
    </div>
  );
}
