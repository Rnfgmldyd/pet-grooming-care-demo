import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Scissors, CheckCircle2, XCircle, Loader2, ArrowLeft, Copy, ExternalLink } from "lucide-react";
import { toast } from "sonner";

// 슬러그 유효성 검사
function isValidSlug(slug: string): boolean {
  return /^[a-z0-9가-힣-]{2,30}$/.test(slug);
}

type RegisterStep = "form" | "success";

export default function RegisterPage() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState<RegisterStep>("form");
  const [registeredSlug, setRegisteredSlug] = useState("");
  const [form, setForm] = useState({
    name: "",
    slug: "",
    phone: "",
    ownerEmail: "",
    description: "",
  });
  const [slugStatus, setSlugStatus] = useState<"idle" | "checking" | "available" | "taken" | "invalid">("idle");
  const [slugDebounceTimer, setSlugDebounceTimer] = useState<ReturnType<typeof setTimeout> | null>(null);

  const utils = trpc.useUtils();
  const registerMutation = trpc.shop.register.useMutation({
    onSuccess: (data) => {
      setRegisteredSlug(data.slug);
      setStep("success");
    },
    onError: (err) => {
      toast.error(err.message || "가입 중 오류가 발생했습니다.");
    },
  });

  // 슬러그 실시간 확인 (디바운스)
  const checkSlug = useCallback(async (slug: string) => {
    if (!slug) { setSlugStatus("idle"); return; }
    if (!isValidSlug(slug)) { setSlugStatus("invalid"); return; }
    setSlugStatus("checking");
    try {
      const result = await utils.shop.checkSlug.fetch({ slug });
      setSlugStatus(result.available ? "available" : "taken");
    } catch {
      setSlugStatus("idle");
    }
  }, [utils]);

  useEffect(() => {
    if (slugDebounceTimer) clearTimeout(slugDebounceTimer);
    const timer = setTimeout(() => checkSlug(form.slug), 500);
    setSlugDebounceTimer(timer);
    return () => clearTimeout(timer);
  }, [form.slug]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (slugStatus !== "available") {
      toast.error("서비스 주소를 확인해주세요.");
      return;
    }
    registerMutation.mutate({
      name: form.name,
      slug: form.slug,
      phone: form.phone,
      ownerEmail: form.ownerEmail,
      description: form.description || undefined,
    });
  };

  const slugHint = {
    idle: null,
    checking: <span className="text-gray-400 flex items-center gap-1"><Loader2 size={12} className="animate-spin" /> 확인 중...</span>,
    available: <span className="text-green-600 flex items-center gap-1"><CheckCircle2 size={12} /> 사용 가능한 주소입니다</span>,
    taken: <span className="text-red-500 flex items-center gap-1"><XCircle size={12} /> 이미 사용 중인 주소입니다</span>,
    invalid: <span className="text-red-500 flex items-center gap-1"><XCircle size={12} /> 영문 소문자, 숫자, 한글, 하이픈만 사용 가능 (2~30자)</span>,
  }[slugStatus];

  // 실제 배포 도메인 기반 링크 생성 (슬러그 기반)
  const origin = window.location.origin;
  const staffLoginUrl = registeredSlug ? `${origin}/s/${registeredSlug}/staff-login` : `${origin}/staff-login`;
  const customerBaseUrl = `${origin}/status/`;

  // ── 가입 완료 화면 ────────────────────────────────────────────────────────────
  if (step === "success") {
    return (
      <div className="min-h-screen bg-[#FAFAF7]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>
        <header className="bg-white border-b border-[#E8EDE8] sticky top-0 z-10">
          <div className="max-w-xl mx-auto px-5 h-14 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#1B4332] flex items-center justify-center">
                <Scissors size={14} className="text-white" />
              </div>
              <span className="font-bold text-[#1B4332] text-sm">그루밍노트</span>
            </div>
          </div>
        </header>

        <div className="max-w-xl mx-auto px-5 py-10">
          {/* 완료 아이콘 */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-full bg-[#D1FAE5] flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 size={32} className="text-[#059669]" />
            </div>
            <h1 className="text-2xl font-bold text-[#1B4332] mb-2" style={{ fontFamily: "'Noto Serif KR', serif" }}>
              가입이 완료되었습니다!
            </h1>
            <p className="text-sm text-[#6B7280]">
              이제 직원 PIN을 설정하고 바로 사용할 수 있습니다.
            </p>
          </div>

          {/* 안내 카드 */}
          <div className="bg-white rounded-2xl border border-[#E8EDE8] p-6 shadow-sm space-y-5 mb-5">
            {/* Step 1: PIN 설정 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-full bg-[#1B4332] text-white flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                1
              </div>
              <div className="flex-1">
                <p className="font-semibold text-[#1B4332] text-sm mb-1">직원 화면 바로 시작하기</p>
                <p className="text-xs text-[#6B7280] mb-3">
                  비밀번호 없이 바로 직원 관리 화면에 접속합니다.
                </p>
                <Button
                  className="bg-[#1B4332] hover:bg-[#145229] text-white text-sm h-10 px-5 rounded-xl"
                  onClick={() => navigate(registeredSlug ? `/s/${registeredSlug}/staff` : "/staff")}
                >
                  직원 화면으로 이동 →
                </Button>
              </div>
            </div>

            <div className="border-t border-[#F3F4F6]" />

            {/* Step 2: 직원 로그인 링크 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-full bg-[#E8EDE8] text-[#6B7280] flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                2
              </div>
              <div className="flex-1">
                <p className="font-semibold text-[#1B4332] text-sm mb-1">직원 로그인 링크</p>
                <p className="text-xs text-[#6B7280] mb-2">
                  이 링크를 즐겨찾기에 저장하거나 직원들에게 공유하세요.
                </p>
                <div className="flex items-center gap-2 bg-[#F4F7F4] rounded-xl px-3 py-2.5 border border-[#E8EDE8]">
                  <span className="text-xs font-mono text-[#1B4332] flex-1 truncate">{staffLoginUrl}</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(staffLoginUrl);
                      toast.success("링크가 복사되었습니다!");
                    }}
                    className="flex-shrink-0 text-[#6B7280] hover:text-[#1B4332] transition-colors"
                  >
                    <Copy size={14} />
                  </button>
                </div>
              </div>
            </div>

            <div className="border-t border-[#F3F4F6]" />

            {/* Step 3: 고객 링크 안내 */}
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-full bg-[#E8EDE8] text-[#6B7280] flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                3
              </div>
              <div className="flex-1">
                <p className="font-semibold text-[#1B4332] text-sm mb-1">보호자 링크 공유 방법</p>
                <p className="text-xs text-[#6B7280] mb-2">
                  접수 등록 후 직원 화면에서 각 반려동물의 링크를 복사해 보호자에게 전달하세요.
                </p>
                <div className="flex items-center gap-2 bg-[#F4F7F4] rounded-xl px-3 py-2.5 border border-[#E8EDE8]">
                  <span className="text-xs font-mono text-[#9CA3AF] flex-1">{customerBaseUrl}<span className="text-[#1B4332]">접수ID</span></span>
                </div>
              </div>
            </div>
          </div>

          {/* 바로 시작하기 */}
          <Button
            className="w-full bg-[#1B4332] hover:bg-[#145229] text-white font-bold h-12 rounded-xl text-sm"
            onClick={() => navigate(registeredSlug ? `/s/${registeredSlug}/staff` : "/staff")}
          >
            지금 바로 시작하기 →
          </Button>

          <p className="text-center text-xs text-[#9CA3AF] mt-4">
            나중에 시작하려면{" "}
            <button onClick={() => navigate("/")} className="text-[#1B4332] hover:underline font-medium">
              홈으로 돌아가기
            </button>
          </p>
        </div>
      </div>
    );
  }

  // ── 가입 폼 ───────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-[#FAFAF7]" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>
      {/* 헤더 */}
      <header className="bg-white border-b border-[#E8EDE8] sticky top-0 z-10">
        <div className="max-w-xl mx-auto px-5 h-14 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-[#1B4332] hover:opacity-70 transition-opacity"
          >
            <ArrowLeft size={18} />
            <span className="text-sm font-medium">그루밍노트</span>
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#1B4332] flex items-center justify-center">
              <Scissors size={14} className="text-white" />
            </div>
            <span className="font-bold text-[#1B4332] text-sm">매장 가입</span>
          </div>
        </div>
      </header>

      <div className="max-w-xl mx-auto px-5 py-10">
        {/* 타이틀 */}
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-[#1B4332] flex items-center justify-center mx-auto mb-4">
            <Scissors size={24} className="text-white" />
          </div>
          <h1
            className="text-2xl font-bold text-[#1B4332] mb-2"
            style={{ fontFamily: "'Noto Serif KR', serif" }}
          >
            그루밍노트 시작하기
          </h1>
          <p className="text-sm text-[#6B7280]">
            무료로 시작하세요. 가입 후 바로 사용 가능합니다.
          </p>
        </div>

        {/* 가입 폼 */}
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-[#E8EDE8] p-7 shadow-sm space-y-5">
          {/* 매장명 */}
          <div>
            <Label htmlFor="name" className="text-sm font-semibold text-[#1B4332] mb-1.5 block">
              매장명 <span className="text-red-500">*</span>
            </Label>
            <Input
              id="name"
              placeholder="예: 몽몽 애견미용실"
              value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              required
              className="border-[#E8EDE8] focus:border-[#1B4332] focus:ring-[#1B4332]/20"
            />
          </div>

          {/* 서비스 주소 (슬러그) */}
          <div>
            <Label htmlFor="slug" className="text-sm font-semibold text-[#1B4332] mb-1.5 block">
              서비스 식별 코드 <span className="text-red-500">*</span>
            </Label>
            <div className="flex items-center gap-2">
              <div className="flex-1 relative">
                <Input
                  id="slug"
                  placeholder="mongmong"
                  value={form.slug}
                  onChange={e => setForm(f => ({ ...f, slug: e.target.value.toLowerCase() }))}
                  required
                  className={`border-[#E8EDE8] focus:border-[#1B4332] focus:ring-[#1B4332]/20 ${
                    slugStatus === "available" ? "border-green-400" :
                    slugStatus === "taken" || slugStatus === "invalid" ? "border-red-400" : ""
                  }`}
                />
              </div>
            </div>
            <div className="mt-1.5 text-xs">
              {slugHint}
              {slugStatus === "idle" && (
                <span className="text-gray-400">영문 소문자, 숫자, 한글, 하이픈 조합 (2~30자)</span>
              )}
            </div>
            <p className="text-xs text-[#9CA3AF] mt-1">
              매장을 구분하는 고유 코드입니다. 나중에 변경할 수 없습니다.
            </p>
          </div>

          {/* 전화번호 */}
          <div>
            <Label htmlFor="phone" className="text-sm font-semibold text-[#1B4332] mb-1.5 block">
              매장 전화번호 <span className="text-red-500">*</span>
            </Label>
            <Input
              id="phone"
              type="tel"
              placeholder="010-1234-5678"
              value={form.phone}
              onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
              required
              className="border-[#E8EDE8] focus:border-[#1B4332] focus:ring-[#1B4332]/20"
            />
          </div>

          {/* 이메일 */}
          <div>
            <Label htmlFor="email" className="text-sm font-semibold text-[#1B4332] mb-1.5 block">
              이메일 <span className="text-red-500">*</span>
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="owner@example.com"
              value={form.ownerEmail}
              onChange={e => setForm(f => ({ ...f, ownerEmail: e.target.value }))}
              required
              className="border-[#E8EDE8] focus:border-[#1B4332] focus:ring-[#1B4332]/20"
            />
          </div>

          {/* 매장 소개 (선택) */}
          <div>
            <Label htmlFor="description" className="text-sm font-semibold text-[#1B4332] mb-1.5 block">
              매장 소개 <span className="text-[#9CA3AF] font-normal">(선택)</span>
            </Label>
            <Input
              id="description"
              placeholder="예: 소형견 전문 · 친절한 미용사"
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              className="border-[#E8EDE8] focus:border-[#1B4332] focus:ring-[#1B4332]/20"
            />
          </div>

          {/* 제출 버튼 */}
          <Button
            type="submit"
            disabled={registerMutation.isPending || slugStatus !== "available"}
            className="w-full bg-[#1B4332] hover:bg-[#145229] text-white font-bold h-12 rounded-xl text-sm mt-2"
          >
            {registerMutation.isPending ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                처리 중...
              </span>
            ) : (
              "무료로 시작하기"
            )}
          </Button>

          <p className="text-xs text-center text-[#9CA3AF]">
            가입 후 직원 PIN을 설정하면 바로 사용 가능합니다.
          </p>
        </form>

        {/* 기능 요약 */}
        <div className="mt-6 grid grid-cols-3 gap-3">
          {[
            { emoji: "🆓", title: "무료 플랜", desc: "기본 기능 모두 포함" },
            { emoji: "⚡", title: "즉시 사용", desc: "설치 없이 바로 시작" },
            { emoji: "🔒", title: "PIN 보안", desc: "직원 전용 4자리 PIN" },
          ].map((item, i) => (
            <div key={i} className="bg-white rounded-xl border border-[#E8EDE8] p-3 text-center">
              <div className="text-xl mb-1">{item.emoji}</div>
              <p className="text-xs font-bold text-[#1B4332]">{item.title}</p>
              <p className="text-[10px] text-[#9CA3AF] mt-0.5">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
